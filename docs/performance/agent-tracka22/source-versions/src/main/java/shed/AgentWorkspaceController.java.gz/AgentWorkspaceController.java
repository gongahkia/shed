package shed;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import javax.swing.SwingUtilities;

/** Human-owned start/stop lifecycle. Machine requests never route through editor commands. */
final class AgentWorkspaceController implements AutoCloseable {
    private final Texteditor editor;
    private final Set<WorkspaceBridgeServer> owned = ConcurrentHashMap.newKeySet();
    private final Set<WorkspaceBridgeServer> releasing = ConcurrentHashMap.newKeySet();
    private final AtomicLong generation = new AtomicLong();
    private final AtomicBoolean disposed = new AtomicBoolean();
    private final AgentSessionRegistry sessions = new AgentSessionRegistry();
    private WorkspaceBridgeServer active;
    private int startingJob = -1;
    private boolean stopping;
    private boolean proposalMode;
    private boolean applicationReady;
    private ApplicationStatus applicationStatus;
    private String status = "Agent API is stopped; no listener is running.";

    AgentWorkspaceController(Texteditor editor) { this.editor = editor; }

    void ownSession(AgentSessionService session) { sessions.own(session); }
    void applicationReady() { applicationReady = true; if (applicationStatus != null) applicationStatus.ready(); }

    String handle(String argument) {
        if (active != null && !active.running()) { active = null; status = "Agent API connection has stopped."; }
        String value = argument == null ? "" : argument.trim();
        return switch (value) {
            case "complete" -> editor.requestAiCompletion();
            case "edit", "ask", "run" -> {
                if (editor.toolWindowHost != null) editor.toolWindowHost.showAgentAction(
                    value.equals("edit") ? AgentAction.EDIT : value.equals("ask") ? AgentAction.ASK : AgentAction.RUN);
                yield "Describe your request in the Assistant panel.";
            }
            case "" -> { editor.showToolWindow(ToolWindowHost.Tab.AGENT); yield "Connect an agent or review proposals in the Agents panel."; }
            case "proposals" -> { if (editor.toolWindowHost != null) editor.toolWindowHost.showAgentReview(); yield "Review proposals in the Agents panel."; }
            case "status", "api", "api status" -> status;
            case "api start" -> start(false, false);
            case "api start propose" -> start(true, false);
            case "api start status" -> start(false, true);
            case "api start metadata" -> start(false, false, true);
            case "api start navigation" -> start(false, false, true, true);
            case "api stop" -> stop();
            default -> "Usage: :agent [edit|ask|run|complete|proposals] or :agent api start [propose|status|metadata|navigation]|status|stop";
        };
    }

    private String start(boolean allowProposals, boolean statusOnly) {
        return start(allowProposals, statusOnly, false);
    }

    private String start(boolean allowProposals, boolean statusOnly, boolean metadataMode) {
        return start(allowProposals, statusOnly, metadataMode, false);
    }

    private String start(boolean allowProposals, boolean statusOnly, boolean metadataMode, boolean navigationMode) {
        if (disposed.get()) return "Agent API is unavailable while the editor closes.";
        if (active != null && active.running()) return active.statusOnly() == statusOnly && active.metadataEnabled() == metadataMode
            && active.navigationEnabled() == navigationMode && proposalMode == allowProposals ? status
            : "Stop the current API before starting it with different permissions.";
        if (startingJob >= 0) return "Agent API startup is already running.";
        Path root = statusOnly ? null : editor.workspaceController.activeRoot();
        if (!statusOnly && root == null) return "Select a workspace folder before starting the agent API.";
        ApplicationStatus capturedStatus = applicationStatus;
        boolean capturedReady = applicationReady;
        if (metadataMode && editor.workspaceController.roots().size() > EditorMetadata.MAX_ROOTS) return "Too many workspace folders for bounded metadata observation.";
        var excludedRoots = statusOnly || metadataMode ? java.util.List.copyOf(editor.workspaceController.roots()) : java.util.List.<Path>of();
        var approval = metadataMode ? new EditorMetadata.Approval(root, editor.workspaceRoots.generation()) : null;
        if (navigationMode && editor.editorPanes.size() > EditorMetadata.MAX_PANES) return "Too many panes for bounded navigation.";
        var interaction = navigationMode ? editor.beginAgentNavigation() : null;
        var editorOwner = new java.lang.ref.WeakReference<>(editor);
        EditorMetadata.Host observationHost = () -> {
            var live = editorOwner.get();
            if (live == null) throw EditorMetadata.failure(WorkspaceApiException.Code.APP_SHUTTING_DOWN);
            return live.captureEditorMetadata();
        };
        EditorNavigation.Host navigationHost = navigationHost(editorOwner);
        long request = generation.incrementAndGet();
        stopping = false;
        Path directory = Path.of(editor.configManager.getSessionDirectory(), "agent-api");
        proposalMode = allowProposals;
        String mode = navigationMode ? "Editor navigation" : metadataMode ? "Editor metadata" : statusOnly ? "Status-only" : allowProposals ? "Proposal-only" : "Read-only";
        AgentPolicy policy = allowProposals ? new AgentPolicy(Set.of(AgentPolicy.Capability.READ, AgentPolicy.Capability.PROPOSE),
            java.util.List.of("**/README.md"), java.util.List.of(), true) : AgentPolicy.readOnly();
        Path sessions = Path.of(editor.configManager.getSessionDirectory());
        status = "Starting " + mode.toLowerCase(java.util.Locale.ROOT) + " agent API…";
        startingJob = editor.asyncJobService.submit("Start local agent API", token -> {
            WorkspaceBridgeServer server;
            if (statusOnly) server = WorkspaceBridgeServer.status(capturedStatus == null ? new ApplicationStatus(capturedReady) : capturedStatus, directory, excludedRoots);
            else if (metadataMode) {
                var application = capturedStatus == null ? new ApplicationStatus(capturedReady) : capturedStatus;
                EditorMetadata observation;
                try { observation = navigationMode ? EditorMetadata.navigation(application, approval, navigationHost, interaction)
                    : new EditorMetadata(application, approval, observationHost); }
                catch (RuntimeException failed) { if (interaction != null) interaction.close(); throw failed; }
                try { server = WorkspaceBridgeServer.metadata(application, observation, directory, excludedRoots); }
                catch (IOException | RuntimeException failed) { observation.close(); throw failed; }
            }
            else {
                var workspace = editor.workspaceQueries(root, policy);
                var proposals = new WorkspaceProposalService(workspace, editor.workspaceDocuments(),
                    sessions.resolve("agent-workspace").resolve(workspace.workspaceId()), "workspace-api");
                server = new WorkspaceBridgeServer(workspace, proposals, directory);
            }
            owned.add(server);
            var owner = new java.lang.ref.WeakReference<>(this);
            var ownedServers = owned; var releasingServers = releasing;
            server.onClosed(() -> {
                ownedServers.remove(server); releasingServers.remove(server);
                var live = owner.get();
                if (live != null && !live.disposed.get()) SwingUtilities.invokeLater(() -> {
                    var controller = owner.get();
                    if (controller != null && !controller.disposed.get() && controller.active == server) {
                        controller.active = null; controller.status = "Agent API attachment has stopped or expired.";
                    }
                });
            });
            token.onCancel(() -> release(server));
            if (disposed.get() || generation.get() != request || token.isCancelled()) { release(server); return null; }
            return server;
        }, (snapshot, server, error) -> {
            if (disposed.get() || generation.get() != request) { if (server != null) release(server); if (interaction != null) interaction.close(); return; }
            startingJob = -1;
            if (error != null || snapshot.getStatus() != AsyncJobService.Status.SUCCEEDED || server == null || !server.running()) {
                if (server != null) release(server);
                if (interaction != null) interaction.close();
                status = "Agent API could not start. Check local diagnostics and owner-only session directory permissions.";
            } else {
                active = server;
                if (statusOnly || metadataMode) {
                    applicationStatus = server.statusApplication();
                    if (applicationReady) applicationStatus.ready();
                }
                status = statusOnly || metadataMode ? mode + " attachment. Descriptor: " + server.descriptor() + ". Credential file: " + server.credential()
                    : mode + " agent API for " + root + ". Connection descriptor: " + server.descriptor();
            }
            editor.showMessage(status);
        });
        return status;
    }

    private static EditorNavigation.Host navigationHost(java.lang.ref.WeakReference<Texteditor> editorOwner) {
        return new EditorNavigation.Host() {
            private Texteditor owner() {
                var live = editorOwner.get();
                if (live == null) throw EditorMetadata.failure(WorkspaceApiException.Code.APP_SHUTTING_DOWN);
                return live;
            }
            public EditorMetadata.Context capture() { return owner().captureEditorMetadata(); }
            public EditorNavigation.State state() { return owner().captureEditorNavigation(); }
            public EditorNavigation.Prepared prepare(EditorNavigation.Command command) { return owner().prepareEditorNavigation(command); }
            public EditorNavigation.Applied apply(EditorNavigation.Prepared prepared, java.util.function.BooleanSupplier authorized) { return owner().applyEditorNavigation(prepared, authorized); }
        };
    }

    private String stop() {
        stopping = true;
        generation.incrementAndGet();
        if (startingJob >= 0) editor.asyncJobService.cancel(startingJob);
        startingJob = -1; active = null;
        if (editor.agentNavigationInteraction != null) { editor.agentNavigationInteraction.close(); editor.agentNavigationInteraction = null; }
        for (WorkspaceBridgeServer server : owned) release(server);
        status = owned.isEmpty() ? "Agent API is stopped; no listener is running."
            : "Agent API stopping; existing connections are being revoked.";
        return status;
    }

    private void release(WorkspaceBridgeServer server) {
        server.revokeObservation();
        if (!releasing.add(server)) return;
        Thread.ofVirtual().name("shed-workspace-stop").start(() -> {
            try { server.close(); }
            catch (IOException cleanup) {
                System.getLogger("shed.workspace").log(System.Logger.Level.WARNING,
                    "Workspace connection stopped; its private descriptor could not be removed.");
            } finally {
                owned.remove(server); releasing.remove(server);
                if (!disposed.get()) SwingUtilities.invokeLater(() -> {
                    if (stopping && owned.isEmpty() && startingJob < 0)
                        status = "Agent API is stopped; no listener is running.";
                });
            }
        });
    }

    @Override public void close() {
        if (applicationStatus != null) applicationStatus.stopping();
        disposed.set(true); sessions.close(); stop();
    }
}
