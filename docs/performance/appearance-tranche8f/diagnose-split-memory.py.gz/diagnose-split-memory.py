import json,pathlib,subprocess,os,time
root=pathlib.Path('/Users/gongahkia/Desktop/coding/projects/shed')
p=pathlib.Path('/tmp/shed-tranche8f-run'); out=p/'split-memory-diagnostic-v2'; out.mkdir()
d=json.loads((p/'split-memory-repeat/report.json').read_text())
java=pathlib.Path(d['cases'][0]['command'][0]); src=out/'DensityPerformanceProbe.java'
text=(root/'src/benchmark/java/shed/DensityPerformanceProbe.java').read_text()
text=text.replace('heap("after_cycles_requested_gc");', '''heap("after_cycles_requested_gc");
            for (String point : List.of("immediate", "settled")) {
                if (point.equals("settled")) {
                    Thread.sleep(2000);
                    for (int i = 0; i < 3; i++) { edt(() -> null); System.gc(); Thread.sleep(100); }
                    heap("active_settled_requested_gc");
                }
                Process diagnostic = new ProcessBuilder(Path.of(System.getProperty("java.home"), "bin", "jcmd").toString(),
                    Long.toString(ProcessHandle.current().pid()), "GC.class_histogram")
                    .redirectErrorStream(true).redirectOutput(output.resolve(point + "-histogram.txt").toFile()).start();
                if (!diagnostic.waitFor(20, java.util.concurrent.TimeUnit.SECONDS)) { diagnostic.destroyForcibly(); throw new AssertionError("Histogram timed out"); }
                if (diagnostic.exitValue() != 0) throw new AssertionError("Histogram failed");
            }''')
src.write_text(text); classes=out/'classes';classes.mkdir()
subprocess.run([str(java.with_name('javac')),'-cp',str(p/'candidate.jar'),'-d',str(classes),str(src),str(root/'src/benchmark/java/shed/MarkdownPerformanceProbe.java'),str(root/'src/benchmark/java/shed/MarkdownLexicalProbe.java')],check=True,timeout=40)
for c in d['cases']:
 label=c['artifact']; run=out/label;(run/'home/.shed').mkdir(parents=True)
 (run/'home/.shed/config.toml').write_text('schema_version = 1\n"theme" = "shed-light"\n"keymap.profile" = "plain"\n"session.restore.on.start" = false\n')
 cmd=c['command'].copy();cmd[4]='-Duser.home='+str(run/'home');cmd[6]=str(classes)+os.pathsep+str(p/(label+'.jar'));cmd[12]=str(run)
 # positional arguments verified against retained original command
 assert cmd[7]=='shed.DensityPerformanceProbe' and cmd[13]=='0'
 with (run/'stdout.log').open('w') as log:
  result=subprocess.run(cmd,cwd=run,stdout=log,stderr=subprocess.STDOUT,timeout=90)
 print(label,result.returncode,flush=True)
 (run/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
 if result.returncode:raise SystemExit(result.returncode)
