"""Same probe and full workload, restricted to the existing 1 MiB wrapped case; no new warmup or GC policy."""
import importlib.util
import sys
from pathlib import Path
root = Path('/Users/gongahkia/Desktop/coding/projects/shed')
spec = importlib.util.spec_from_file_location('density_memory_pair', root / 'scripts/benchmark-density.py')
tool = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tool)
tool.CASES = [tool.CASES[4]]
sys.exit(tool.main())
