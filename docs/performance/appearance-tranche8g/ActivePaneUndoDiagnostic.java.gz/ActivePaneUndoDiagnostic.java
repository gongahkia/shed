package shed;
import java.nio.file.*;
import java.awt.Window;
import javax.swing.Timer;
import static shed.MarkdownPerformanceProbe.*;
public final class ActivePaneUndoDiagnostic {
    public static void main(String[] args) throws Exception {
        Texteditor editor = edt(() -> new Texteditor(new String[]{args[0]}));
        await(() -> editor.getCurrentBuffer() != null && args[0].equals(editor.getCurrentBuffer().getFilePath()) && !editor.stagedStartupPending, 30);
        try {
            edt(() -> {
                var source = editor.getCurrentBuffer(); var original = editor.getActivePane();
                source.getDocument().insertString(0, "draft ", null); source.getUndoManager().undo();
                original.getTextArea().setCaretPosition(1); original.getTextArea().moveCaretPosition(3);
                for (int i=0;i<12;i++) {
                    editor.splitWindow(i%2==0);
                    for(int j=0;j<8;j++)editor.cycleWindowFocus();
                    editor.closeActiveWindow();
                }
                System.out.println("UNDO_DIAGNOSTIC before_redo document="+source.getDocument().getLength()+" snapshot="+source.textSnapshot().length());
                try {
                    source.getUndoManager().redo();
                    System.out.println("UNDO_DIAGNOSTIC REDO_PASS text="+source.getContent().replace("\n","\\n"));
                    source.getUndoManager().undo();
                    System.out.println("UNDO_DIAGNOSTIC UNDO_PASS text="+source.getContent().replace("\n","\\n"));
                } catch(Throwable error) {
                    System.out.println("UNDO_DIAGNOSTIC ERROR "+error);error.printStackTrace(System.out);
                    System.out.println("UNDO_DIAGNOSTIC after_error document="+source.getDocument().getLength()+" snapshot="+source.textSnapshot().length());
                }
                return null;
            });
        } finally {
            edt(() -> {
                for (Timer timer : new Timer[]{editor.messageResetTimer,editor.externalChangeTimer,editor.recoverySnapshotTimer,editor.diagnosticRefreshTimer})if(timer!=null)timer.stop();
                editor.fileWatcherService.stop();editor.shutdownSyntaxUi();editor.shutdownLspScheduling();editor.shutdownRecoveryJournalScheduling();
                editor.asyncJobService.shutdownNow();editor.backupScheduler.close();editor.treeGitController.closeFinderIndexes();editor.paletteController.close();
                editor.testController.shutdown();editor.debugSessionController.shutdown();editor.remoteWorkspaceController.closeAll();
                for(Window w:Window.getWindows())w.dispose();return null;
            });
            System.exit(0);
        }
    }
}
