from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/Users/gongahkia/Desktop/coding/projects/shed');p=Path('/tmp/shed-tranche8g1-run')
env=os.environ.copy()
for key in ['JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS','CLASSPATH']:env.pop(key,None)
env['PYTHONDONTWRITEBYTECODE']='1'
cmd=['python3',str(root/'scripts/benchmark-active-pane.py'),'--jar',str(p/'candidate.jar'),'--baseline-jar',str(p/'baseline.jar'),'--output',str(p/'verified-matrix'),'--lifecycle-only']
with (p/'verified-matrix.log').open('w') as log:subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
classes=p/'diagnostic-verified-classes';classes.mkdir()
sources=[root/'src/benchmark/java/shed'/f'{name}.java' for name in ['SplitLifecycleDiagnostic','MarkdownPerformanceProbe','MarkdownLexicalProbe']]
subprocess.run([env['JAVA_HOME']+'/bin/javac','-cp',str(p/'candidate.jar'),'-d',str(classes),*map(str,sources)],cwd=root,env=env,check=True,timeout=40)
out=p/'verified-rooted-diagnostic';out.mkdir();report={'jars':{label:hashlib.sha256((p/(label+'.jar')).read_bytes()).hexdigest() for label in ['baseline','candidate']},'probe_hashes':{str(s.relative_to(root)):hashlib.sha256(s.read_bytes()).hexdigest() for s in sources},'cases':[]}
for fixture,text in [('ascii','body\n'),('unicode','é😀 क्ष\n')]:
 for label in ['baseline','candidate']:
  run=out/(label+'-'+fixture);(run/'home/.shed').mkdir(parents=True)
  (run/'source.md').write_text(text);(run/'home/.shed/config.toml').write_text('schema_version = 1\n"theme" = "shed-light"\n"session.restore.on.start" = false\n')
  cmd=[env['JAVA_HOME']+'/bin/java','-Xms64m','-Xmx512m','-Djava.awt.headless=false','-Duser.home='+str(run/'home'),'-cp',str(classes)+':'+str(p/(label+'.jar')),'shed.SplitLifecycleDiagnostic',str(run/'source.md'),str(label=='candidate').lower()]
  with (run/'stdout.log').open('w') as log:r=subprocess.run(cmd,cwd=run,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=60)
  log=(run/'stdout.log').read_text()
  case={'artifact':label,'fixture':fixture,'command':cmd,'exit':r.returncode,'complete':'SPLIT_DONE' in log,'events':[json.loads(l[6:]) for l in log.splitlines() if l.startswith('SPLIT ')]}
  report['cases'].append(case);(out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(label,fixture,r.returncode,case['complete'],flush=True)
  if r.returncode or not case['complete']:raise SystemExit(1)
