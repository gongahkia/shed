import importlib.util, json, os, subprocess, sys, time
from pathlib import Path
ROOT=Path('/Users/gongahkia/Desktop/coding/projects/shed')
RUN=Path('/tmp/shed-tranche8h-run')
JAR=RUN/'qualification.jar'
JDK=Path('/tmp/shed-tranche2b-tools/jdk-21.0.13+9/Contents/Home')
os.environ['PYTHONDONTWRITEBYTECODE']='1'
def module(name):
 s=importlib.util.spec_from_file_location(name, ROOT/'scripts'/f'{name}.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
results=[]
def standard(name, overrides, args):
 m=module(name)
 for key,value in overrides.items():setattr(m,key,value)
 sys.argv=[str(ROOT/'scripts'/f'{name}.py'),*args]
 start=time.time()
 with (RUN/f'{name}.log').open('w') as log:
  oldout,olderr=sys.stdout,sys.stderr
  try:sys.stdout=sys.stderr=log;code=m.main()
  finally:sys.stdout,sys.stderr=oldout,olderr
 results.append(dict(stage=name,exit=code,seconds=time.time()-start,args=args))
 (RUN/'final-controls.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,code,flush=True)
def child(name, command, timeout):
 start=time.monotonic();rss=[]
 with (RUN/f'{name}.log').open('w') as log:
  p=subprocess.Popen(command,cwd=RUN,stdout=log,stderr=subprocess.STDOUT)
  while p.poll() is None and time.monotonic()-start<timeout:
   try:rss.append(float(subprocess.check_output(['/bin/ps','-o','rss=','-p',str(p.pid)],text=True))/1024)
   except (ValueError,subprocess.CalledProcessError):pass
   time.sleep(.25)
  expired=p.poll() is None
  if expired:
   p.terminate()
   try:p.wait(2)
   except subprocess.TimeoutExpired:p.kill();p.wait()
 results.append(dict(stage=name,exit=p.returncode,timeout=expired,seconds=time.monotonic()-start,command=command,rss_mib=rss))
 (RUN/'final-controls.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,p.returncode,flush=True)
common=['--jar',str(JAR),'--baseline-jar',str(JAR)]
standard('benchmark-active-pane', {'SIZES':[1048576]}, common+['--output',str(RUN/'pane-verified'),'--lifecycle-only'])
standard('benchmark-focus-mode', {'CASES':[(10485760,False,False),(102400,True,False)]}, ['--jar',str(JAR),'--output',str(RUN/'focus-current')])
standard('benchmark-theme-preview', {'CASES':[(4096,False,True),(102400,True,False)]},common+['--output',str(RUN/'theme-current')])
standard('benchmark-editor',{},['--jar',str(JAR),'--runs','3','--label','8h-current','--output',str(RUN/'startup.json')])
classes=RUN/'visual-classes'
sources=[ROOT/'src/benchmark/java/shed'/f'{name}.java' for name in ['AppearanceQualificationProbe','SplitLifecycleDiagnostic','MarkdownPerformanceProbe','MarkdownLexicalProbe']]
subprocess.run([str(JDK/'bin/javac'),'-cp',str(JAR),'-d',str(classes),*map(str,sources)],check=True)
for label,text in [('visual','# Source alpha\nUnicode: e\u0301, क्ष, 👩\u200d💻, 中文\n'*10),('rooted','body\n')]:
 home=RUN/f'{label}-home';(home/'.shed').mkdir(parents=True)
 (home/'.shed/config.toml').write_text('schema_version = 1\n"theme" = "shed-light"\n"keymap.profile" = "plain"\n"session.restore.on.start" = false\n')
 file=RUN/f'{label}.md';file.write_text(text)
 cmd=[str(JDK/'bin/java'),'-Xms64m','-Xmx512m','-Djava.awt.headless=false',f'-Duser.home={home}','-cp',os.pathsep.join([str(classes),str(JAR)])]
 cmd+=['shed.AppearanceQualificationProbe',str(file),str(RUN/'visual')] if label=='visual' else ['shed.SplitLifecycleDiagnostic',str(file),'true']
 child(label,cmd,90)
