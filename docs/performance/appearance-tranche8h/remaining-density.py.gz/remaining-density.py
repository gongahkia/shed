import importlib.util, sys
from pathlib import Path
r=Path("/Users/gongahkia/Desktop/coding/projects/shed")
s=importlib.util.spec_from_file_location("density", r/"scripts/benchmark-density.py")
m=importlib.util.module_from_spec(s); s.loader.exec_module(m)
m.CASES=m.CASES[2:]
sys.argv=[str(r/"scripts/benchmark-density.py"),"--jar","/tmp/shed-tranche8h-run/qualification.jar","--baseline-jar","/tmp/shed-tranche8h-run/qualification.jar","--output","/tmp/shed-tranche8h-run/density-remaining"]
raise SystemExit(m.main())
