import json,os,subprocess,time
from pathlib import Path
R=Path('/tmp/shed-trackb0-run');JDK=Path('/tmp/shed-tranche2b-tools/jdk-21.0.13+9/Contents/Home');F=(R/'final-matrix/fixtures').resolve();records=[]
env=os.environ.copy()
for key in ['JAVA_TOOL_OPTIONS','JDK_JAVA_OPTIONS','_JAVA_OPTIONS','CLASSPATH']:env.pop(key,None)
env.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL=os.devnull)
for label,mode,nmt in [('native-memory','basic',True),('shutdown-active','shutdown-active',False)]:
 folder=R/label;(folder/'home/.shed').mkdir(parents=True)
 (folder/'home/.shed/config.toml').write_text('schema_version=1\n"theme"="shed-light"\n"keymap.profile"="plain"\n"session.restore.on.start"=false\n')
 command=[str(JDK/'bin/java'),'-Xms64m','-Xmx512m','-Djava.awt.headless=false',f'-Duser.home={folder/"home"}']
 if nmt:command+=['-XX:NativeMemoryTracking=summary','-Db0.diagnostic.hold.ms=5000']
 command+=['-cp',os.pathsep.join([str(R/'classes'),str(R/'baseline.jar')]),'shed.WholeIdeDesktopProbe',mode,str(F/'Main.java'),str(F)]
 result={'label':label,'command':command,'rss':[],'diagnostics':[],'load_before':os.getloadavg()};start=time.monotonic();diagnosed=False
 with (folder/'stdout.log').open('w') as log:
  p=subprocess.Popen(command,cwd=F,env=env,stdout=log,stderr=subprocess.STDOUT)
  while p.poll() is None and time.monotonic()-start<30:
   try:result['rss'].append({'elapsed_s':time.monotonic()-start,'mib':float(subprocess.check_output(['/bin/ps','-o','rss=','-p',str(p.pid)],text=True))/1024})
   except (ValueError,subprocess.CalledProcessError):pass
   if nmt and not diagnosed and 'diagnostic_hold' in (folder/'stdout.log').read_text():
    diagnosed=True
    for name,args in [('nmt',[str(JDK/'bin/jcmd'),str(p.pid),'VM.native_memory','summary']),('vmmap',['/usr/bin/vmmap','-summary',str(p.pid)])]:
     t=time.monotonic()
     try:
      d=subprocess.run(args,capture_output=True,text=True,timeout=3)
      (folder/f'{name}.log').write_text(d.stdout+d.stderr);result['diagnostics'].append({'name':name,'command':args,'exit':d.returncode,'seconds':time.monotonic()-t})
     except subprocess.TimeoutExpired:result['diagnostics'].append({'name':name,'timeout':True})
   time.sleep(.1)
  if p.poll() is None:p.terminate();p.wait(2);result['timeout']=True
 result.update(exit=p.returncode,ended_epoch_ms=time.time()*1000,elapsed_s=time.monotonic()-start,events=[json.loads(l[3:]) for l in (folder/'stdout.log').read_text().splitlines() if l.startswith('B0 ')])
 ids=[v for e in result['events'] if e['operation']=='shutdown_background_ready' for v in e['owned_children']]
 time.sleep(.5)
 result['owned_children_after_half_second']=[{'pid':v['pid'],'alive':subprocess.run(['/bin/ps','-p',str(v['pid'])],stdout=subprocess.DEVNULL).returncode==0} for v in ids]
 records.append(result);(R/'extra-controls.json').write_text(json.dumps(records,indent=2)+'\n');print(label,p.returncode,flush=True)
root=F/'project-1000';file=root/'dir-000/File00000.java';before=file.read_bytes();git=[]
def run(args,label,sample=0):
 start=time.monotonic();p=subprocess.run(['/usr/bin/git',*args],cwd=root,env=env,capture_output=True,text=True,timeout=3)
 git.append({'operation':label,'sample':sample,'ms':(time.monotonic()-start)*1000,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0,p.stderr
try:
 for i in range(26):run(['status','--porcelain=v1','--branch'],'git_status',i)
 run(['add','--',str(file.relative_to(root))],'git_stage')
 file.write_bytes(before+b'// B0 external modification\n')
 for i in range(26):run(['diff','--no-ext-diff','--',str(file.relative_to(root))],'git_worktree_diff',i)
 run(['diff','--cached','--name-only'],'git_staged_diff')
finally:
 run(['rm','--cached','--force','--',str(file.relative_to(root))],'git_unstage_unborn')
 file.write_bytes(before)
(R/'git-control.json').write_text(json.dumps({'method':'direct Git CLI reference, not complete Shed UI; synthetic unborn repo, no commits','environment':{'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':os.devnull},'events':git},indent=2)+'\n')
print('git',len(git),flush=True)
