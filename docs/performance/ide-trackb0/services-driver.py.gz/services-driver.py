import os,subprocess,time,json,hashlib
from pathlib import Path
r=Path('/tmp/shed-trackb0-run');f=r/'fixtures';f.mkdir()
for n in [100,1000,5000]:
 p=f/f'project-{n}';p.mkdir()
 for i in range(n):
  d=p/f'dir-{i//100:03}';d.mkdir(exist_ok=True)
  (d/f'File{i:05}.java').write_text(f'class File{i} {{}}\n'+('unique-b0-target\n' if i==n-1 else 'ordinary source\n'))
(f/'Main.java').write_text('class Main {}\n')
(r/'fixtures.json').write_text(json.dumps({str(p.relative_to(f)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in f.rglob('*') if p.is_file()},indent=2)+'\n')
jdk=Path('/tmp/shed-tranche2b-tools/jdk-21.0.13+9/Contents/Home');(r/'services-home').mkdir()
cmd=[str(jdk/'bin/java'),'-Xms64m','-Xmx512m','-XX:NativeMemoryTracking=summary',f'-Duser.home={r/"services-home"}','-cp',os.pathsep.join([str(r/'classes'),str(r/'baseline.jar')]),'shed.WholeIdeServicesProbe',str(f)]
result={'command':cmd,'rss':[],'load_before':os.getloadavg()};start=time.monotonic()
with (r/'services.log').open('w') as log:
 p=subprocess.Popen(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT)
 while p.poll() is None and time.monotonic()-start<120:
  try:result['rss'].append({'elapsed':time.monotonic()-start,'mib':float(subprocess.check_output(['/bin/ps','-o','rss=','-p',str(p.pid)],text=True))/1024})
  except (ValueError,subprocess.CalledProcessError):pass
  time.sleep(.25)
 if p.poll() is None:p.kill();p.wait();result['timeout']=True
result.update(exit=p.returncode,load_after=os.getloadavg(),events=[json.loads(l[3:]) for l in (r/'services.log').read_text().splitlines() if l.startswith('B0 ')])
(r/'services-report.json').write_text(json.dumps(result,indent=2)+'\n')
print('services',p.returncode)
