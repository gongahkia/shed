import json,math,hashlib,shutil,subprocess
from pathlib import Path
R=Path('/tmp/shed-trackb0-run')
def stats(v):
 v=sorted(v)
 if not v:return None
 r={'n':len(v),'min':v[0],'max':v[-1],'p50':v[max(0,math.ceil(.5*len(v))-1)]}
 if len(v)>=20:r['observed_p95']=v[math.ceil(.95*len(v))-1]
 if len(v)>=50:r['observed_p99']=v[math.ceil(.99*len(v))-1]
 return r
reports={}
for label,name in [('matrix','final-matrix/report.json'),('interference','interference-verified/report.json'),('input_readiness','input-readiness/report.json')]:
 report=json.loads((R/name).read_text());rows=[]
 for case in report['cases']:
  row={k:case[k] for k in ['label','exit','elapsed_s']};row['sampled_rss_mib']=stats([v['mib']for v in case['rss']]);groups={}
  for event in case['events']:
   op=event['operation']+(':first' if event.get('sample')==0 else ':warm' if 'sample'in event else '')
   for key,value in event.items():
    if key not in ['epoch_ms','sample'] and isinstance(value,(int,float)) and not isinstance(value,bool):groups.setdefault(op,{}).setdefault(key,[]).append(value)
  row['operations']={op:{key:stats(values) for key,values in fields.items()} for op,fields in groups.items()}
  row['states']=[v for v in case['events'] if 'heap_used_mib'in v or v['operation']in['caught_bad_location_geometry','load_timeout','native_capture','visual_source_integrity']]
  if label=='input_readiness':row['first_synthetic_input_paint_observed_from_spawn_ms']=next(e['epoch_ms'] for e in case['events'] if e['operation']=='ordinary_input'and e['sample']==0)-case['spawn_epoch_ms']
  rows.append(row)
 reports[label]=rows
reports['extra']=json.loads((R/'extra-controls.json').read_text())
reports['unicode']=json.loads((R/'unicode-report.json').read_text())
reports['git']={op:stats([e['ms'] for e in json.loads((R/'git-control.json').read_text())['events'] if e['operation']==op])for op in ['git_status','git_worktree_diff','git_stage','git_staged_diff','git_unstage_unborn']}
reports['source_counts']={'production_java_files':len(list(Path('src/main/java/shed').glob('*.java'))),'test_java_files':len(list(Path('src/test/java/shed').glob('*.java')))}
(R/'summary.json').write_text(json.dumps(reports,indent=2)+'\n')
(R/'tool-availability.json').write_text(json.dumps({name:shutil.which(name)for name in ['git','sh','bash','zsh','fish','node','python3','cmake','ctest','cpack','docker','devcontainer','dotnet','opencode','gh','psql','sqlite3','mysql','swift']},indent=2)+'\n')
for row in reports['matrix']:
 print(row['label'],[v for v in row['states'] if v['operation']=='before_shutdown'])
print('git',reports['git'])
