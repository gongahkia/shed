import os,subprocess,time,json
from pathlib import Path
r=Path('/tmp/shed-trackb0-run');home=r/'unicode-home';(home/'.shed').mkdir(parents=True)
(home/'.shed/config.toml').write_text('schema_version=1\n"theme"="shed-light"\n"keymap.profile"="plain"\n"session.restore.on.start"=false\n')
jdk=Path('/tmp/shed-tranche2b-tools/jdk-21.0.13+9/Contents/Home');file=(r/'final-matrix/fixtures/source-1048576.java').resolve()
cmd=[str(jdk/'bin/java'),'-Xms64m','-Xmx512m','-Djava.awt.headless=false',f'-Duser.home={home}','-cp',os.pathsep.join([str(r/'classes'),str(r/'baseline.jar')]),'shed.UnicodeLayoutProbe',str(file),'production','false']
case={'command':cmd,'rss':[],'load_before':os.getloadavg()};start=time.monotonic()
with (r/'unicode.log').open('w') as log:
 p=subprocess.Popen(cmd,cwd=r,stdout=log,stderr=subprocess.STDOUT)
 while p.poll() is None and time.monotonic()-start<90:
  try:case['rss'].append({'elapsed_s':time.monotonic()-start,'mib':float(subprocess.check_output(['/bin/ps','-o','rss=','-p',str(p.pid)],text=True))/1024})
  except (ValueError,subprocess.CalledProcessError):pass
  time.sleep(.25)
 if p.poll() is None:p.terminate();p.wait(2);case['timeout']=True
case.update(exit=p.returncode,events=[l for l in (r/'unicode.log').read_text().splitlines() if l.startswith('MD_')],load_after=os.getloadavg())
(r/'unicode-report.json').write_text(json.dumps(case,indent=2)+'\n');print('unicode',p.returncode)
