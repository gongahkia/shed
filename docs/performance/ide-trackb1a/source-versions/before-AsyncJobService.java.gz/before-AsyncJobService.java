package shed;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import javax.swing.SwingUtilities;

public class AsyncJobService {
    public enum Status {
        RUNNING,
        SUCCEEDED,
        FAILED,
        CANCELLED
    }

    public interface JobTask<T> {
        T run(JobToken token) throws Exception;
    }

    public interface JobCompletion<T> {
        // invoked on the Swing event dispatch thread
        void onComplete(JobSnapshot snapshot, T result, Exception error);
    }

    public static final class JobToken {
        private volatile boolean cancelled;
        private boolean finished;
        private final List<Runnable> cancelHooks;

        private JobToken() {
            this.cancelled = false;
            this.cancelHooks = Collections.synchronizedList(new ArrayList<>());
        }

        public boolean isCancelled() {
            return cancelled;
        }

        public void onCancel(Runnable hook) {
            if (hook == null) {
                return;
            }
            boolean runNow;
            synchronized (cancelHooks) {
                if (finished) return;
                runNow = cancelled;
                if (!runNow) cancelHooks.add(hook);
            }
            if (runNow) hook.run();
        }

        private void cancel() {
            List<Runnable> hooks;
            synchronized (cancelHooks) {
                if (finished || cancelled) return;
                cancelled = true;
                if (cancelHooks.isEmpty()) return;
                hooks = new ArrayList<>(cancelHooks);
                cancelHooks.clear();
            }
            for (Runnable hook : hooks) {
                try { hook.run(); } catch (Exception ignored) { }
            }
        }

        private void finish() {
            synchronized (cancelHooks) {
                finished = true;
                cancelHooks.clear();
            }
        }
    }

    public static final class JobSnapshot {
        private final int id;
        private final String description;
        private final Status status;
        private final long startedAtMillis;
        private final Long finishedAtMillis;
        private final String errorMessage;

        private JobSnapshot(int id, String description, Status status, long startedAtMillis, Long finishedAtMillis, String errorMessage) {
            this.id = id;
            this.description = description;
            this.status = status;
            this.startedAtMillis = startedAtMillis;
            this.finishedAtMillis = finishedAtMillis;
            this.errorMessage = errorMessage;
        }

        public int getId() {
            return id;
        }

        public String getDescription() {
            return description;
        }

        public Status getStatus() {
            return status;
        }

        public long getStartedAtMillis() {
            return startedAtMillis;
        }

        public Long getFinishedAtMillis() {
            return finishedAtMillis;
        }

        public String getErrorMessage() {
            return errorMessage;
        }
    }

    private static final class JobRecord {
        private final int id;
        private final String description;
        private final long startedAtMillis;
        private volatile Long finishedAtMillis;
        private volatile Status status;
        private volatile String errorMessage;
        private volatile Future<?> future;
        private volatile boolean started;
        private volatile Runnable cancelledBeforeStart;
        private final JobToken token;

        private JobRecord(int id, String description) {
            this.id = id;
            this.description = description;
            this.startedAtMillis = System.currentTimeMillis();
            this.finishedAtMillis = null;
            this.status = Status.RUNNING;
            this.errorMessage = "";
            this.started = false;
            this.cancelledBeforeStart = null;
            this.token = new JobToken();
        }

        private JobSnapshot snapshot() {
            return new JobSnapshot(id, description, status, startedAtMillis, finishedAtMillis, errorMessage);
        }
    }

    private final ExecutorService executor;
    private final ExecutorService longRunningExecutor;
    private final AtomicInteger nextId;
    private final Map<Integer, JobRecord> jobs;
    private final int maxHistoryEntries;
    private final ApplicationErrorReporter errorReporter;
    private volatile Consumer<JobSnapshot> failedJobListener;

    public AsyncJobService() {
        this(200, null);
    }

    public AsyncJobService(int maxHistoryEntries) {
        this(maxHistoryEntries, null);
    }

    public AsyncJobService(int maxHistoryEntries, ApplicationErrorReporter errorReporter) {
        this(Executors.newFixedThreadPool(workerCount(), task -> {
            Thread thread = new Thread(task, "shed-worker");
            thread.setDaemon(true);
            return thread;
        }), maxHistoryEntries, errorReporter);
    }

    AsyncJobService(ExecutorService executor, int maxHistoryEntries, ApplicationErrorReporter errorReporter) {
        this.executor = executor == null ? Executors.newFixedThreadPool(workerCount()) : executor;
        this.longRunningExecutor = Executors.newThreadPerTaskExecutor(Thread.ofVirtual().name("shed-long-running-", 0).factory());
        this.nextId = new AtomicInteger(1);
        this.jobs = new ConcurrentHashMap<>();
        this.maxHistoryEntries = Math.max(10, maxHistoryEntries);
        this.errorReporter = errorReporter;
        this.failedJobListener = snapshot -> { };
    }

    static int workerCount() {
        return Math.max(2, Math.min(4, Runtime.getRuntime().availableProcessors()));
    }

    void setFailedJobListener(Consumer<JobSnapshot> listener) {
        failedJobListener = listener == null ? snapshot -> { } : listener;
    }

    public <T> int submit(String description, JobTask<T> task, JobCompletion<T> completion) {
        return submit(executor, description, task, completion);
    }

    /** Runs an explicitly user-started long-lived process without occupying the bounded worker pool. */
    public <T> int submitLongRunning(String description, JobTask<T> task, JobCompletion<T> completion) {
        return submit(longRunningExecutor, description, task, completion);
    }

    private <T> int submit(ExecutorService targetExecutor, String description, JobTask<T> task, JobCompletion<T> completion) {
        if (task == null) {
            throw new IllegalArgumentException("task must not be null");
        }
        int id = nextId.getAndIncrement();
        JobRecord record = new JobRecord(id, description == null ? "job-" + id : description);
        jobs.put(id, record);
        java.util.concurrent.atomic.AtomicBoolean completionDelivered = new java.util.concurrent.atomic.AtomicBoolean(false);
        record.cancelledBeforeStart = () -> {
            if (completion != null && completionDelivered.compareAndSet(false, true)) {
                JobSnapshot snapshot = record.snapshot();
                SwingUtilities.invokeLater(() -> completeOnEventDispatchThread(
                    completion, snapshot, null, new CancellationException("cancelled"), record.description
                ));
            }
        };

        Future<?> future;
        try {
            future = targetExecutor.submit(() -> {
            record.started = true;
            T result = null;
            Exception error = null;
            try {
                result = task.run(record.token);
                if (record.token.isCancelled() || Thread.currentThread().isInterrupted()) {
                    record.status = Status.CANCELLED;
                } else {
                    record.status = Status.SUCCEEDED;
                }
            } catch (InterruptedException | CancellationException e) {
                record.status = Status.CANCELLED;
                record.errorMessage = e.getMessage() == null ? "" : e.getMessage();
                Thread.currentThread().interrupt();
                error = e instanceof Exception ? (Exception) e : new Exception(e);
            } catch (Exception e) {
                record.status = record.token.isCancelled() ? Status.CANCELLED : Status.FAILED;
                record.errorMessage = e.getMessage() == null ? "" : e.getMessage();
                error = e;
            } catch (Throwable failure) {
                record.status = record.token.isCancelled() ? Status.CANCELLED : Status.FAILED;
                record.errorMessage = failure.getMessage() == null ? failure.getClass().getSimpleName() : failure.getMessage();
                error = new Exception("Unexpected background job failure", failure);
                reportUnexpected(failure, "running async job " + record.description);
            } finally {
                record.cancelledBeforeStart = null;
                record.token.finish();
                record.finishedAtMillis = System.currentTimeMillis();
                trimHistoryIfNeeded();
                JobSnapshot snapshot = record.snapshot();
                reportFailedJob(snapshot);
                if (completion != null && completionDelivered.compareAndSet(false, true)) {
                    T completedResult = result;
                    Exception completedError = error;
                    SwingUtilities.invokeLater(() -> completeOnEventDispatchThread(
                        completion,
                        snapshot,
                        completedResult,
                        completedError,
                        record.description
                    ));
                }
            }
            });
        } catch (RejectedExecutionException error) {
            record.cancelledBeforeStart = null;
            record.token.finish();
            record.status = Status.CANCELLED;
            record.errorMessage = "executor is shut down";
            record.finishedAtMillis = System.currentTimeMillis();
            trimHistoryIfNeeded();
            reportFailedJob(record.snapshot());
            if (completion != null && completionDelivered.compareAndSet(false, true)) {
                JobSnapshot snapshot = record.snapshot();
                SwingUtilities.invokeLater(() -> completeOnEventDispatchThread(completion, snapshot, null,
                    new CancellationException("executor is shut down"), record.description));
            }
            return id;
        }

        record.future = future;
        // Cancellation or shutdown may have raced with the executor's submit return.
        if (record.token.isCancelled() || targetExecutor.isShutdown()) cancel(id);
        return id;
    }

    public boolean cancel(int id) {
        JobRecord record = jobs.get(id);
        if (record == null) {
            return false;
        }
        if (record.status != Status.RUNNING) {
            return false;
        }
        record.token.cancel();
        Future<?> future = record.future;
        if (future != null && future.cancel(true) && !record.started) {
            record.status = Status.CANCELLED;
            record.errorMessage = "cancelled";
            record.finishedAtMillis = System.currentTimeMillis();
            trimHistoryIfNeeded();
            Runnable completion = record.cancelledBeforeStart;
            record.cancelledBeforeStart = null;
            record.token.finish();
            if (completion != null) completion.run();
        }
        return true;
    }

    public JobSnapshot get(int id) {
        JobRecord record = jobs.get(id);
        return record == null ? null : record.snapshot();
    }

    public List<JobSnapshot> list() {
        List<JobSnapshot> snapshots = new ArrayList<>();
        for (JobRecord record : jobs.values()) {
            snapshots.add(record.snapshot());
        }
        snapshots.sort((left, right) -> Integer.compare(right.getId(), left.getId()));
        return snapshots;
    }

    public void shutdownNow() {
        for (JobRecord record : jobs.values()) {
            if (record.status == Status.RUNNING) {
                cancel(record.id);
            }
        }
        executor.shutdownNow();
        longRunningExecutor.shutdownNow();
        // Include submissions accepted between the first cancellation pass and shutdown.
        for (JobRecord record : jobs.values()) {
            if (record.status == Status.RUNNING) cancel(record.id);
        }
    }

    private void trimHistoryIfNeeded() {
        if (jobs.size() <= maxHistoryEntries) {
            return;
        }
        List<JobRecord> finished = new ArrayList<>();
        for (JobRecord record : jobs.values()) {
            if (record.status != Status.RUNNING) {
                finished.add(record);
            }
        }
        finished.sort((left, right) -> Long.compare(left.startedAtMillis, right.startedAtMillis));
        int trimCount = jobs.size() - maxHistoryEntries;
        for (int i = 0; i < finished.size() && trimCount > 0; i++) {
            jobs.remove(finished.get(i).id);
            trimCount--;
        }
    }

    private void reportUnexpected(Throwable failure, String context) {
        if (errorReporter != null) {
            errorReporter.report(failure, "async-jobs", context, "docs/THREADING.md#background-work");
        }
    }

    private void reportFailedJob(JobSnapshot snapshot) {
        if (snapshot == null || snapshot.getStatus() != Status.FAILED) {
            return;
        }
        try {
            failedJobListener.accept(snapshot);
        } catch (RuntimeException error) {
            reportUnexpected(error, "recording failed async job " + snapshot.getDescription());
        }
    }

    private <T> void completeOnEventDispatchThread(
        JobCompletion<T> completion,
        JobSnapshot snapshot,
        T result,
        Exception error,
        String description
    ) {
        try {
            completion.onComplete(snapshot, result, error);
        } catch (Throwable failure) {
            reportUnexpected(failure, "completing async job " + description);
        }
    }
}
