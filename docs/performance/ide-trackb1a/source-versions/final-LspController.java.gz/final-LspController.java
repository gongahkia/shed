package shed;

import javax.swing.*;
import javax.swing.Timer;
import javax.swing.text.BadLocationException;
import javax.swing.text.DefaultHighlighter;
import javax.swing.text.Highlighter;
import java.awt.Color;
import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.List;

final class LspController {
    private static final int CHANGE_DEBOUNCE_MS = 120;
    private static final int DECORATION_DEBOUNCE_MS = 350;
    private static final int MAX_INLINE_INLAY_HINTS = 160;
    private final Texteditor editor;
    private final ManagedLanguageSupportService managedLanguageSupport;
    private final WorkspaceSymbolCoordinator workspaceSymbolCoordinator;
    private final Map<String, LspDocumentSyncState> documentSyncStates = new HashMap<>();
    private final Map<LspServerKey, RemoteLspEndpoint> remoteLspEndpoints = new HashMap<>();
    private Timer lspChangeTimer;
    private FileBuffer pendingLspChange;
    private Timer lspDecorationTimer;
    private FileBuffer pendingLspDecoration;
    private int lspDecorationJobId = -1;
    private int documentHighlightJobId = -1;
    private long documentHighlightGeneration;
    private int workspaceSymbolQueryGeneration;
    private LspDefinitionRequests definitionRequests;
    private int codeActionJobId = -1;
    private long codeActionGeneration;
    private final Map<LspServerKey, Integer> automaticLaunchJobs = new HashMap<>();
    private final Set<LspServerKey> failedAutomaticLaunches = new HashSet<>();

    private record CodeActionRequest(FileBuffer buffer, LspClient client, String uri, Integer version, int caretOffset,
                                     int line, int column, List<LspClient.Diagnostic> diagnostics, int requestedIndex, long generation) { }
    private record CodeActionResult(CodeActionRequest request, List<LspClient.CodeAction> actions) { }
    private record AutomaticLspStart(LspClient client, RemoteLspEndpoint endpoint) { }

    LspController(Texteditor editor) {
        this.editor = editor;
        Path managedLanguageDirectory = editor != null && editor.configManager != null
            ? Path.of(editor.configManager.getShedDirectoryPath()) : Path.of(System.getProperty("user.home"), ".shed");
        this.managedLanguageSupport = new ManagedLanguageSupportService(new LanguageServerDetector(null, null, null),
            ManagedLanguageDistributionCatalog.trust(), managedLanguageDirectory,
            ManagedLanguageSupportService.platformFor(System.getProperty("os.name")));
        this.workspaceSymbolCoordinator = new WorkspaceSymbolCoordinator(editor);
    }

    String getWordAtCaret() {
        String text = editor.writingArea.getText();
        int caret = editor.writingArea.getCaretPosition();
        if (text.isEmpty() || caret >= text.length()) return "";
        int start = caret, end = caret;
        while (start > 0 && editor.isWordCharacter(text.charAt(start - 1))) start--;
        while (end < text.length() && editor.isWordCharacter(text.charAt(end))) end++;
        return start == end ? "" : text.substring(start, end);
    }


    public String showLspCompletionStatus() {
        FileBuffer buffer = editor.getCurrentBuffer();
        String prefix = currentCompletionPrefix();
        List<String> completions = new ArrayList<>();
        LspClient client = resolveLspClient(buffer);
        String fallbackReason = null;
        if (buffer != null && client != null && buffer.hasFilePath()) {
            if (!client.supports(LspCapability.COMPLETION)) {
                fallbackReason = client.capabilityUnavailableReason(LspCapability.COMPLETION);
            } else {
                String uri = bufferUri(buffer);
                try {
                    int line = editor.writingArea.getLineOfOffset(editor.writingArea.getCaretPosition());
                    int column = editor.writingArea.getCaretPosition() - editor.writingArea.getLineStartOffset(line);
                    List<LspClient.CompletionItem> items = client.completion(uri, line, column);
                    for (LspClient.CompletionItem item : items) {
                        if (item.getLabel() != null && !item.getLabel().isEmpty()) {
                            completions.add(item.getLabel());
                        }
                    }
                } catch (BadLocationException ignored) {
                }
            }
        } else if (buffer != null) {
            fallbackReason = lspErrorFor(buffer);
        }

        if (completions.isEmpty()) {
            if (prefix.isEmpty()) {
                return fallbackReason == null ? "No completion prefix" : "LSP unavailable: " + fallbackReason;
            }
            completions = collectBufferCompletions(prefix);
        }
        if (completions.isEmpty()) {
            return fallbackReason == null ? "No completions" : "LSP unavailable: " + fallbackReason + "; no local completions";
        }
        String selection = editor.showPaletteDialog("Completions", completions);
        if (selection == null || selection.isEmpty()) {
            return "Completion cancelled";
        }
        applyCompletion(prefix, selection);
        return fallbackReason == null ? "Inserted completion" : "Inserted completion (local fallback; LSP unavailable: " + fallbackReason + ")";
    }


    public String handleLspCommand(String argument) {
        flushPendingLspChange(editor.getCurrentBuffer());
        String trimmed = argument == null ? "" : argument.trim();
        if (trimmed.isEmpty() || "help".equals(trimmed)) {
            return "Usage: :lsp completion|definition|type definition|implementation|highlights [clear]|calls incoming|outgoing|typehierarchy supertypes|subtypes|hover|semantic|inlay|codelens [index]|selection [expand]|links [index]|colors|folding|pulldiagnostics|workspacediagnostics|references|rename <newName>|renameapply|renamecancel|codeaction [index]";
        }
        int split = trimmed.indexOf(' ');
        String subcommand = split < 0 ? trimmed.toLowerCase() : trimmed.substring(0, split).toLowerCase();
        String args = split < 0 ? "" : trimmed.substring(split + 1).trim();
        switch (subcommand) {
            case "completion":
            case "complete":
            case "comp":
                return showLspCompletionStatus();
            case "definition":
            case "def":
                return lspGoToDefinition();
            case "typedefinition":
            case "type-definition":
            case "type":
            case "typedef":
                return lspGoToTypeDefinition();
            case "implementation":
            case "implementations":
            case "impl":
                return lspGoToImplementation();
            case "highlights":
            case "documenthighlights":
                return lspDocumentHighlights(args);
            case "hover":
                return lspHover();
            case "semantic":
            case "semantictokens":
                return lspSemanticTokens();
            case "inlay":
            case "inlayhints":
                return lspInlayHints();
            case "codelens":
            case "code-lens":
            case "lenses":
                return lspCodeLenses(args);
            case "selection":
            case "selectionrange":
            case "selection-ranges":
                return lspSelectionRange(args);
            case "links":
            case "documentlinks":
            case "document-links":
                return lspDocumentLinks(args);
            case "colors":
            case "documentcolors":
            case "document-colors":
                return lspDocumentColors();
            case "pulldiagnostics":
            case "pull-diagnostics":
            case "pulldiag":
                return lspPullDiagnostics();
            case "workspacediagnostics":
            case "workspace-diagnostics":
            case "workspacediag":
                return lspWorkspaceDiagnostics();
            case "folding":
            case "foldingranges":
            case "folding-ranges":
                return lspFoldingRanges();
            case "format":
                return lspFormat();
            case "calls":
            case "callhierarchy":
                return lspCallHierarchy(args);
            case "typehierarchy":
            case "type-hierarchy":
                return lspTypeHierarchy(args);
            case "references":
            case "refs":
                return lspReferences();
            case "rename":
                return lspRename(args);
            case "renameapply":
            case "rename!":
                return lspRenameApply();
            case "renamecancel":
            case "renameclear":
                return lspRenameCancel();
            case "codeaction":
            case "codeactions":
            case "actions":
            case "ca":
                if ("apply".equalsIgnoreCase(args)) return lspCodeActionApply();
                return lspCodeActions(args);
            case "diagnostics":
            case "diag":
                return showDiagnostics();
            case "status":
                return lspStatus();
            case "restart":
                return lspRestart(args);
            case "stop":
                return lspStop(args);
            case "servers":
                return lspServers();
            case "manage":
            case "manager":
                return lspManage(args);
            case "log":
                return lspLog();
            default:
                return "Unknown :lsp subcommand: " + subcommand;
        }
    }


    public String lspStatus() {
        StringBuilder sb = new StringBuilder();
        sb.append("LSP Server Status\n");
        sb.append("=".repeat(40)).append("\n\n");
        if (editor.lspClients.isEmpty() && editor.lspErrors.isEmpty()) {
            sb.append("No LSP servers active.\n");
            sb.append("Open a file with a configured language to start a server.\n");
        }
        for (Map.Entry<LspServerKey, LspClient> entry : editor.lspClients.entrySet()) {
            LspServerKey key = entry.getKey();
            LspClient client = entry.getValue();
            sb.append("  ").append(key.displayName()).append("  ");
            sb.append(client.isAlive() ? "running" : "stopped");
            Path root = key.workspaceRoot();
            if (root != null) {
                sb.append("  ").append(root);
            }
            sb.append("\n");
            for (LspCapability capability : LspCapability.values()) {
                if (client.capabilityAvailability(capability) != LspCapabilityModel.Availability.AVAILABLE) {
                    sb.append("    ").append(client.capabilityUnavailableReason(capability)).append("\n");
                }
            }
        }
        if (!editor.lspErrors.isEmpty()) {
            sb.append("\nErrors:\n");
            for (Map.Entry<LspServerKey, String> entry : editor.lspErrors.entrySet()) {
                LspServerKey key = entry.getKey();
                sb.append("  ").append(key.displayName());
                if (key.workspaceRoot() != null) sb.append("  ").append(key.workspaceRoot());
                sb.append(": ").append(entry.getValue()).append("\n");
            }
        }
        sb.append("\nManaged support: :lsp manage (detect/install/update/remove/retry/manual)\n");
        editor.showScratchBuffer("[lsp status]", sb.toString());
        return "Showing LSP status";
    }


    public String lspRestart(String ext) {
        cancelDefinition();
        String extension = ext.isEmpty() ? currentBufferExtension() : ext.replace(".", "").toLowerCase();
        if (extension.isEmpty()) return "No extension specified and no file open";
        int stopped = stopServersForExtension(extension);
        removeErrorsForExtension(extension);
        // remove document versions for this extension so didOpen fires again
        editor.lspDocumentVersions.entrySet().removeIf(e -> {
            String uri = e.getKey();
            int dot = uri.lastIndexOf('.');
            return dot >= 0 && uri.substring(dot + 1).equalsIgnoreCase(extension);
        });
        documentSyncStates.entrySet().removeIf(e -> hasExtension(e.getKey(), extension));
        FileBuffer buf = editor.getCurrentBuffer();
        if (buf != null && bufferExtension(buf).equals(extension)) {
            LspClient client = resolveLspClient(buf);
            if (client != null) return "Restarted LSP for ." + extension;
            return "Failed to restart LSP for ." + extension;
        }
        return stopped == 0 ? "No LSP server running for ." + extension + " (will start on next use)"
            : "Stopped " + stopped + " LSP server" + (stopped == 1 ? "" : "s") + " for ." + extension + " (will restart on next use)";
    }


    public String lspStop(String ext) {
        cancelDefinition();
        String extension = ext.isEmpty() ? currentBufferExtension() : ext.replace(".", "").toLowerCase();
        if (extension.isEmpty()) return "No extension specified and no file open";
        int stopped = stopServersForExtension(extension);
        if (stopped == 0) return "No LSP server running for ." + extension;
        removeErrorsForExtension(extension);
        return "Stopped " + stopped + " LSP server" + (stopped == 1 ? "" : "s") + " for ." + extension;
    }


    public String lspServers() {
        StringBuilder sb = new StringBuilder();
        sb.append("LSP Servers\n");
        sb.append("=".repeat(40)).append("\n\n");
        Map<String, String> configured = editor.configManager.getConfiguredLspServers();
        sb.append("Configured (config.toml):\n");
        if (configured.isEmpty()) {
            sb.append("  (none)\n");
        } else {
            for (Map.Entry<String, String> entry : configured.entrySet()) {
                sb.append("  .").append(entry.getKey()).append(" -> ").append(entry.getValue()).append("\n");
            }
        }
        sb.append("\nBuiltin:\n");
        for (String ext : editor.lspService.getBuiltinExtensions()) {
            if (configured.containsKey(ext)) continue;
            String[] cmd = editor.lspService.builtinCommand(ext);
            if (cmd != null) {
                sb.append("  .").append(ext).append(" -> ").append(String.join(" ", cmd)).append("\n");
            }
        }
        editor.showScratchBuffer("[lsp servers]", sb.toString());
        return "Showing LSP servers";
    }

    private String lspManage(String argument) {
        String trimmed = argument == null ? "" : argument.trim();
        if (trimmed.isEmpty() || "ui".equalsIgnoreCase(trimmed) || "gui".equalsIgnoreCase(trimmed)) {
            ManagedLanguageServicesDialog.showFor(editor, managedLanguageSupport);
            return "Opened language services";
        }
        if ("status".equalsIgnoreCase(trimmed) || "list".equalsIgnoreCase(trimmed)) {
            editor.showScratchBuffer("[lsp manage]", managedLanguageSupport.overview());
            return "Showing managed LSP support";
        }
        int split = trimmed.indexOf(' ');
        String action = (split < 0 ? trimmed : trimmed.substring(0, split)).toLowerCase(Locale.ROOT);
        String target = split < 0 ? "" : trimmed.substring(split + 1).trim();
        if (target.isEmpty()) target = currentBufferExtension();
        if (target.isEmpty()) return "Usage: :lsp manage detect|install|update|remove|retry|manual <extension>";
        ManagedLanguageCatalog.Entry entry = managedLanguageSupport.entryFor(target);
        if (entry == null) return "No managed LSP catalog entry for: " + target;
        return switch (action) {
            case "detect", "retry" -> startManagedLspDetection(entry);
            case "install", "update" -> {
                ManagedLanguageServicesDialog.showFor(editor, managedLanguageSupport, entry);
                yield "Opened language services for " + action;
            }
            case "remove", "uninstall" -> managedLanguageSupport.remove(entry).detail();
            case "manual", "configure", "config" -> showManagedLspText("[lsp manual " + target + "]",
                managedLanguageSupport.manualInstructions(entry), "Showing manual LSP setup");
            default -> "Unknown :lsp manage action: " + action;
        };
    }

    private String startManagedLspDetection(ManagedLanguageCatalog.Entry entry) {
        int jobId = editor.asyncJobService.submit("LSP detection: " + entry.displayName(), token -> managedLanguageSupport.detect(entry),
            (snapshot, result, error) -> {
                if (snapshot.getStatus() == AsyncJobService.Status.SUCCEEDED && result != null) {
                    editor.showMessage(entry.displayName() + " detection complete; run :lsp manage to review");
                } else {
                    editor.showMessage(entry.displayName() + " detection failed: " + (error == null ? snapshot.getErrorMessage() : error.getMessage()));
                }
            });
        return "LSP detection job " + jobId + " started";
    }

    private String showManagedLspText(String title, String text, String result) {
        editor.showScratchBuffer(title, text);
        return result;
    }


    public String lspLog() {
        if (editor.lspErrors.isEmpty()) return "No LSP errors";
        StringBuilder sb = new StringBuilder();
        sb.append("LSP Error Log\n");
        sb.append("=".repeat(40)).append("\n\n");
        for (Map.Entry<LspServerKey, String> entry : editor.lspErrors.entrySet()) {
            LspServerKey key = entry.getKey();
            sb.append(key.displayName());
            if (key.workspaceRoot() != null) sb.append("  ").append(key.workspaceRoot());
            sb.append(": ").append(entry.getValue()).append("\n");
        }
        editor.showScratchBuffer("[lsp log]", sb.toString());
        return "Showing LSP log";
    }


    String currentBufferExtension() {
        FileBuffer buf = editor.getCurrentBuffer();
        return buf == null ? "" : bufferExtension(buf);
    }


    public String lspGoToDefinition() {
        FileBuffer buffer = editor.getCurrentBuffer();
        EditorPane pane = editor.getActivePane();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile() || pane == null || pane.isDisposed()) {
            return "LSP definition requires a file-backed buffer";
        }
        LspClient client = existingLspClient(buffer);
        if (client == null || !client.isAlive()) {
            startLspAutomatically(buffer);
            return "LSP unavailable: language server is starting or not configured; retry definition when ready";
        }
        String unavailable = capabilityUnavailable(client, LspCapability.DEFINITION);
        if (unavailable != null) return unavailable;
        syncLspOpen(buffer);
        flushPendingLspChange(buffer);
        String uri = bufferUri(buffer);
        try {
            var context = LspDefinitionRequests.Context.capture(buffer, pane, client, uri, editor.lspDocumentVersions.get(uri));
            if (definitionRequests == null) {
                definitionRequests = new LspDefinitionRequests(editor.asyncJobService,
                    location -> editor.showMessage(openLspLocation(location, "definition")), editor::showMessage);
            }
            return definitionRequests.request(context, () -> definitionContextCurrent(context));
        } catch (BadLocationException error) {
            return "LSP definition failed: " + error.getMessage();
        }
    }

    private boolean definitionContextCurrent(LspDefinitionRequests.Context context) {
        if (editor.closingDown || !editor.buffers.contains(context.buffer()) || context.pane().isDisposed()
            || editor.getCurrentBuffer() != context.buffer() || editor.getActivePane() != context.pane()) return false;
        return context.current(editor.getCurrentBuffer(), editor.getActivePane(), existingLspClient(context.buffer()),
            bufferUri(context.buffer()), editor.lspDocumentVersions.get(context.uri()), editor.closingDown);
    }

    void cancelDefinition() {
        if (definitionRequests != null) definitionRequests.cancel();
    }

    public String lspGoToTypeDefinition() {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) return "LSP type definition requires a file-backed buffer";
        LspClient client = resolveLspClient(buffer);
        if (client == null) return "LSP unavailable";
        String unavailable = capabilityUnavailable(client, LspCapability.TYPE_DEFINITION);
        if (unavailable != null) return unavailable;
        syncLspOpen(buffer);
        String uri = bufferUri(buffer);
        try {
            int line = editor.writingArea.getLineOfOffset(editor.writingArea.getCaretPosition());
            int column = editor.writingArea.getCaretPosition() - editor.writingArea.getLineStartOffset(line);
            LspClient.Location location = client.typeDefinition(uri, line, column);
            if (location == null) return "No type definition found";
            return openLspLocation(location, "type definition");
        } catch (BadLocationException error) {
            return "LSP type definition failed: " + error.getMessage();
        }
    }

    public String lspGoToImplementation() {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) return "LSP implementation requires a file-backed buffer";
        LspClient client = resolveLspClient(buffer);
        if (client == null) return "LSP unavailable";
        String unavailable = capabilityUnavailable(client, LspCapability.IMPLEMENTATION);
        if (unavailable != null) return unavailable;
        syncLspOpen(buffer);
        String uri = bufferUri(buffer);
        try {
            int line = editor.writingArea.getLineOfOffset(editor.writingArea.getCaretPosition());
            int column = editor.writingArea.getCaretPosition() - editor.writingArea.getLineStartOffset(line);
            List<LspClient.Location> locations = client.implementations(uri, line, column);
            if (locations.isEmpty()) {
                editor.problemsController.clearQuickfixSource("lsp");
                return "No implementations found";
            }
            if (locations.size() == 1) return openLspLocation(locations.getFirst(), "implementation");
            return showLspLocationsInQuickfix("implementations", locations);
        } catch (BadLocationException error) {
            return "LSP implementation failed: " + error.getMessage();
        }
    }

    public String lspDocumentHighlights(String argument) {
        String action = argument == null ? "" : argument.trim().toLowerCase(Locale.ROOT);
        if ("clear".equals(action)) {
            boolean hadHighlights = !editor.lspDocumentHighlightTags.isEmpty();
            clearDocumentHighlights();
            return hadHighlights ? "Cleared document highlights" : "No document highlights";
        }
        if (!action.isEmpty()) return "Usage: :lsp highlights [clear]";
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) return "LSP document highlights require a file-backed buffer";
        LspClient client = resolveLspClient(buffer);
        if (client == null) return "LSP unavailable";
        String unavailable = capabilityUnavailable(client, LspCapability.DOCUMENT_HIGHLIGHTS);
        if (unavailable != null) return unavailable;
        syncLspOpen(buffer);
        flushPendingLspChange(buffer);
        String uri = bufferUri(buffer);
        Integer version = editor.lspDocumentVersions.get(uri);
        if (version == null) return "LSP document highlights unavailable";
        try {
            int caret = editor.writingArea.getCaretPosition();
            int line = editor.writingArea.getLineOfOffset(caret);
            int column = caret - editor.writingArea.getLineStartOffset(line);
            clearDocumentHighlights();
            long generation = ++documentHighlightGeneration;
            DocumentHighlightRequest request = new DocumentHighlightRequest(buffer, client, uri, version, buffer.textSnapshot(), generation, line, column);
            documentHighlightJobId = editor.asyncJobService.submit("LSP document highlights", token -> {
                List<LspClient.DocumentHighlight> highlights = request.client().documentHighlights(request.uri(), request.line(), request.column());
                return token.isCancelled() ? null : new DocumentHighlightResult(request, highlights);
            }, (snapshot, result, error) -> applyDocumentHighlights(snapshot, result, error));
            return "Loading document highlights (job " + documentHighlightJobId + ")";
        } catch (BadLocationException error) {
            return "LSP document highlights failed: " + error.getMessage();
        }
    }

    private String lspCallHierarchy(String argument) {
        String direction = argument == null ? "" : argument.trim().toLowerCase(Locale.ROOT);
        if (!"incoming".equals(direction) && !"outgoing".equals(direction)) return "Usage: :lsp calls incoming|outgoing";
        return requestHierarchy(true, direction);
    }

    private String lspTypeHierarchy(String argument) {
        String direction = argument == null ? "" : argument.trim().toLowerCase(Locale.ROOT);
        if (!"supertypes".equals(direction) && !"subtypes".equals(direction)) return "Usage: :lsp typehierarchy supertypes|subtypes";
        return requestHierarchy(false, direction);
    }

    private String requestHierarchy(boolean callHierarchy, String direction) {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) return "LSP hierarchy requires a file-backed buffer";
        LspClient client = resolveLspClient(buffer);
        if (client == null) return "LSP unavailable";
        LspCapability capability = callHierarchy ? LspCapability.CALL_HIERARCHY : LspCapability.TYPE_HIERARCHY;
        String unavailable = capabilityUnavailable(client, capability);
        if (unavailable != null) return unavailable;
        try {
            syncLspOpen(buffer);
            String uri = bufferUri(buffer);
            int caret = editor.writingArea.getCaretPosition();
            int line = editor.writingArea.getLineOfOffset(caret);
            int column = caret - editor.writingArea.getLineStartOffset(line);
            Integer version = editor.lspDocumentVersions.get(uri);
            editor.asyncJobService.submit("LSP hierarchy prepare", token -> callHierarchy
                ? client.prepareCallHierarchy(uri, line, column) : client.prepareTypeHierarchy(uri, line, column), (job, roots, error) -> {
                    if (job.getStatus() == AsyncJobService.Status.CANCELLED) { editor.showMessage("LSP hierarchy cancelled"); return; }
                    if (error != null) { editor.showMessage("LSP hierarchy failed: " + error.getMessage()); return; }
                    if (editor.getCurrentBuffer() != buffer || editor.writingArea.getCaretPosition() != caret
                        || !Objects.equals(editor.lspDocumentVersions.get(uri), version)) { editor.showMessage("LSP hierarchy became stale"); return; }
                    if (roots == null || roots.isEmpty()) { editor.showMessage("No LSP hierarchy target found"); return; }
                    String title = "LSP " + (callHierarchy ? "Call" : "Type") + " Hierarchy — " + direction;
                    LspHierarchyDialog.show(editor, title, roots, item -> {
                        if (callHierarchy) {
                            List<LspClient.CallHierarchyCall> calls = "incoming".equals(direction) ? client.incomingCalls(item) : client.outgoingCalls(item);
                            return calls.stream().map(LspClient.CallHierarchyCall::item).toList();
                        }
                        return "supertypes".equals(direction) ? client.typeSupertypes(item) : client.typeSubtypes(item);
                    });
                });
            return "LSP hierarchy requested";
        } catch (BadLocationException error) {
            return "LSP hierarchy failed: " + error.getMessage();
        }
    }


    public String lspHover() {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) {
            return "LSP hover requires a file-backed buffer";
        }
        LspClient client = resolveLspClient(buffer);
        if (client == null) {
            return "LSP unavailable";
        }
        String unavailable = capabilityUnavailable(client, LspCapability.HOVER);
        if (unavailable != null) return unavailable;
        syncLspOpen(buffer);
        String uri = bufferUri(buffer);
        try {
            int line = editor.writingArea.getLineOfOffset(editor.writingArea.getCaretPosition());
            int column = editor.writingArea.getCaretPosition() - editor.writingArea.getLineStartOffset(line);
            String hoverText = client.hover(uri, line, column);
            if (hoverText == null || hoverText.isBlank()) {
                return "No hover information";
            }
            ShedInformationDialog.showFor(editor, "Hover Information", hoverText.strip() + "\n");
            return "Showing hover";
        } catch (BadLocationException e) {
            return "LSP hover failed: " + e.getMessage();
        }
    }

    public String lspSemanticTokens() {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) return "LSP semantic tokens require a file-backed buffer";
        LspClient client = resolveLspClient(buffer);
        if (client == null) return "LSP unavailable";
        String unavailable = capabilityUnavailable(client, LspCapability.SEMANTIC_TOKENS);
        if (unavailable != null) return unavailable;
        syncLspOpen(buffer);
        String uri = bufferUri(buffer);
        Integer version = editor.lspDocumentVersions.get(uri);
        List<LspClient.SemanticToken> tokens = client.semanticTokens(uri);
        if (!Objects.equals(version, editor.lspDocumentVersions.get(uri))) return "Semantic tokens became stale; refresh again";
        StringBuilder text = new StringBuilder("LSP Semantic Tokens\n\n");
        for (LspClient.SemanticToken token : tokens) text.append(token.line() + 1).append(":").append(token.character() + 1)
            .append(" length ").append(token.length()).append(" type ").append(token.type()).append("\n");
        if (tokens.isEmpty()) text.append("No semantic tokens\n");
        editor.showScratchBuffer("[lsp semantic]", text.toString());
        return "Showing semantic tokens";
    }

    public String lspInlayHints() {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) return "LSP inlay hints require a file-backed buffer";
        LspClient client = resolveLspClient(buffer);
        if (client == null) return "LSP unavailable";
        String unavailable = capabilityUnavailable(client, LspCapability.INLAY_HINTS);
        if (unavailable != null) return unavailable;
        syncLspOpen(buffer);
        String uri = bufferUri(buffer);
        try {
            int lastLine = Math.max(0, editor.writingArea.getLineCount() - 1);
            int lastCharacter = editor.writingArea.getDocument().getLength() - editor.writingArea.getLineStartOffset(lastLine);
            Integer version = editor.lspDocumentVersions.get(uri);
            List<LspClient.InlayHint> hints = client.inlayHints(uri, lastLine, lastCharacter);
            if (!Objects.equals(version, editor.lspDocumentVersions.get(uri))) return "Inlay hints became stale; refresh again";
            StringBuilder text = new StringBuilder("LSP Inlay Hints\n\n");
            for (LspClient.InlayHint hint : hints) text.append(hint.line() + 1).append(":").append(hint.character() + 1)
                .append("  ").append(hint.label()).append("\n");
            if (hints.isEmpty()) text.append("No inlay hints\n");
            editor.showScratchBuffer("[lsp inlay]", text.toString());
            return "Showing inlay hints";
        } catch (BadLocationException error) {
            return "LSP inlay hints failed: " + error.getMessage();
        }
    }

    public String lspCodeLenses(String selectionArgument) {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) return "LSP code lenses require a file-backed buffer";
        LspClient client = resolveLspClient(buffer);
        if (client == null) return "LSP unavailable";
        String unavailable = capabilityUnavailable(client, LspCapability.CODE_LENS);
        if (unavailable != null) return unavailable;
        int requestedIndex = parseOneBasedIndex(selectionArgument);
        if (selectionArgument != null && !selectionArgument.isBlank() && requestedIndex < 1) return "Usage: :lsp codelens [index]";
        syncLspOpen(buffer);
        flushPendingLspChange(buffer);
        String uri = bufferUri(buffer);
        Integer version = editor.lspDocumentVersions.get(uri);
        List<LspClient.CodeLens> lenses = client.codeLenses(uri);
        if (!Objects.equals(version, editor.lspDocumentVersions.get(uri))) return "Code lenses became stale; refresh again";
        if (lenses.isEmpty()) return "No code lenses";
        if (requestedIndex < 1) {
            StringBuilder text = new StringBuilder("LSP Code Lenses\n\n");
            for (int i = 0; i < lenses.size(); i++) {
                LspClient.CodeLens lens = lenses.get(i);
                String title = lens.getTitle().isBlank() ? "(unresolved code lens)" : editor.safePreviewText(lens.getTitle(), 160);
                text.append(i + 1).append(". ").append(lens.getLine() + 1).append(":").append(lens.getCharacter() + 1)
                    .append("  ").append(title).append(lens.hasCommand() ? "\n" : "  (no executable command)\n");
            }
            text.append("\nRun :lsp codelens <index> to execute an available lens.\n");
            editor.showScratchBuffer("[lsp code lenses]", text.toString());
            return "Showing " + lenses.size() + " code lens" + (lenses.size() == 1 ? "" : "es");
        }
        if (requestedIndex > lenses.size()) return "Code lens index out of range: " + requestedIndex;
        LspClient.CodeLens lens = lenses.get(requestedIndex - 1);
        if (!lens.hasCommand()) return "Code lens " + requestedIndex + " has no executable command";
        unavailable = capabilityUnavailable(client, LspCapability.EXECUTE_COMMAND);
        if (unavailable != null) return unavailable;
        if (!client.executeCommand(lens.getCommandId(), lens.getCommandArguments())) return "Code lens command failed";
        String title = lens.getTitle().isBlank() ? lens.getCommandId() : editor.safePreviewText(lens.getTitle(), 160);
        return "Executed code lens: " + title;
    }

    public String lspSelectionRange(String argument) {
        if (argument != null && !argument.isBlank() && !"expand".equalsIgnoreCase(argument.trim())) {
            return "Usage: :lsp selection [expand]";
        }
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) return "LSP selection ranges require a file-backed buffer";
        LspClient client = resolveLspClient(buffer);
        if (client == null) return "LSP unavailable";
        String unavailable = capabilityUnavailable(client, LspCapability.SELECTION_RANGES);
        if (unavailable != null) return unavailable;
        syncLspOpen(buffer);
        flushPendingLspChange(buffer);
        String uri = bufferUri(buffer);
        Integer version = editor.lspDocumentVersions.get(uri);
        VersionedTextSnapshot text = buffer.textSnapshot();
        int caret = editor.writingArea.getCaretPosition();
        VersionedTextSnapshot.Position position = text.positionAt(caret);
        int currentStart = editor.writingArea.getSelectionStart();
        int currentEnd = editor.writingArea.getSelectionEnd();
        List<LspClient.SelectionRange> ranges = client.selectionRanges(uri, position.line(), position.character());
        if (text != buffer.textSnapshot() || !Objects.equals(version, editor.lspDocumentVersions.get(uri))) {
            return "Selection ranges became stale; refresh again";
        }
        for (LspClient.SelectionRange range : ranges) {
            GraphemeEditRange.Range candidate = selectionRangeOffsets(text, range);
            if (candidate == null || candidate.empty() || candidate.start() > currentStart || candidate.end() < currentEnd
                || (candidate.start() == currentStart && candidate.end() == currentEnd)) continue;
            editor.writingArea.setCaretPosition(candidate.start());
            editor.writingArea.moveCaretPosition(candidate.end());
            return "Expanded selection to " + (range.startLine() + 1) + ":" + (range.startCharacter() + 1)
                + "–" + (range.endLine() + 1) + ":" + (range.endCharacter() + 1);
        }
        return "No larger LSP selection range";
    }

    private static GraphemeEditRange.Range selectionRangeOffsets(VersionedTextSnapshot text, LspClient.SelectionRange range) {
        if (text == null || range == null) return null;
        int start = strictOffsetForPosition(text, range.startLine(), range.startCharacter());
        int end = strictOffsetForPosition(text, range.endLine(), range.endCharacter());
        if (start < 0 || end < start) return null;
        return GraphemeEditRange.selection(text.text(), start, end);
    }

    private static int strictOffsetForPosition(VersionedTextSnapshot text, int line, int character) {
        if (line < 0 || character < 0 || line >= text.lineCount()) return -1;
        int start = text.lineStartOffset(line);
        int end = text.lineEndOffset(line);
        return character > end - start ? -1 : start + character;
    }

    public String lspDocumentLinks(String selectionArgument) {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) return "LSP document links require a file-backed buffer";
        LspClient client = resolveLspClient(buffer);
        if (client == null) return "LSP unavailable";
        String unavailable = capabilityUnavailable(client, LspCapability.DOCUMENT_LINKS);
        if (unavailable != null) return unavailable;
        int requestedIndex = parseOneBasedIndex(selectionArgument);
        if (selectionArgument != null && !selectionArgument.isBlank() && requestedIndex < 1) return "Usage: :lsp links [index]";
        syncLspOpen(buffer);
        flushPendingLspChange(buffer);
        String uri = bufferUri(buffer);
        Integer version = editor.lspDocumentVersions.get(uri);
        List<LspClient.DocumentLink> links = client.documentLinks(uri);
        if (!Objects.equals(version, editor.lspDocumentVersions.get(uri))) return "Document links became stale; refresh again";
        if (links.isEmpty()) return "No document links";
        if (requestedIndex < 1) {
            StringBuilder text = new StringBuilder("LSP Document Links\n\n");
            for (int i = 0; i < links.size(); i++) {
                LspClient.DocumentLink link = links.get(i);
                String target = link.hasTarget() ? editor.safePreviewText(link.getTarget(), 180) : "(unresolved link)";
                text.append(i + 1).append(". ").append(link.getStartLine() + 1).append(":").append(link.getStartCharacter() + 1)
                    .append("–").append(link.getEndLine() + 1).append(":").append(link.getEndCharacter() + 1).append("  ").append(target);
                if (!link.getTooltip().isBlank()) text.append("  — ").append(editor.safePreviewText(link.getTooltip(), 120));
                text.append('\n');
            }
            text.append("\nRun :lsp links <index> to open a resolved link.\n");
            editor.showScratchBuffer("[lsp document links]", text.toString());
            return "Showing " + links.size() + " document link" + (links.size() == 1 ? "" : "s");
        }
        if (requestedIndex > links.size()) return "Document link index out of range: " + requestedIndex;
        return openLspDocumentLink(buffer, links.get(requestedIndex - 1));
    }

    private String openLspDocumentLink(FileBuffer source, LspClient.DocumentLink link) {
        if (link == null || !link.hasTarget()) return "Document link has no target";
        try {
            URI uri = new URI(link.getTarget());
            String scheme = uri.getScheme();
            if (scheme == null) {
                File parent = source == null || source.getFile() == null ? null : source.getFile().getAbsoluteFile().getParentFile();
                if (parent == null) return "Document link source has no parent folder";
                File target = new File(parent, uri.getPath() == null ? link.getTarget() : uri.getPath());
                if (!target.isFile()) return "Linked file not found: " + target.getPath();
                editor.openFileAsync(target);
                return "Opening document link: " + target.getName();
            }
            if ("file".equalsIgnoreCase(scheme)) {
                File target = Path.of(uri).toFile();
                if (!target.isFile()) return "Linked file not found: " + target.getPath();
                editor.openFileAsync(target);
                return "Opening document link: " + target.getName();
            }
            if (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme) && !"mailto".equalsIgnoreCase(scheme)) {
                return "Unsupported document-link scheme: " + scheme;
            }
            if (!java.awt.Desktop.isDesktopSupported()) return "Desktop links are unavailable";
            java.awt.Desktop.getDesktop().browse(uri);
            return "Opened document link";
        } catch (IOException | URISyntaxException | IllegalArgumentException error) {
            return "Document link failed: " + error.getMessage();
        }
    }

    public String lspDocumentColors() {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) return "LSP document colors require a file-backed buffer";
        LspClient client = resolveLspClient(buffer);
        if (client == null) return "LSP unavailable";
        String unavailable = capabilityUnavailable(client, LspCapability.DOCUMENT_COLORS);
        if (unavailable != null) return unavailable;
        syncLspOpen(buffer);
        flushPendingLspChange(buffer);
        String uri = bufferUri(buffer);
        Integer version = editor.lspDocumentVersions.get(uri);
        List<LspClient.DocumentColor> colors = client.documentColors(uri);
        if (!Objects.equals(version, editor.lspDocumentVersions.get(uri))) return "Document colors became stale; refresh again";
        StringBuilder text = new StringBuilder("LSP Document Colors\n\n");
        for (LspClient.DocumentColor color : colors) {
            text.append(color.startLine() + 1).append(":").append(color.startCharacter() + 1)
                .append("–").append(color.endLine() + 1).append(":").append(color.endCharacter() + 1)
                .append("  ").append(color.hexValue()).append('\n');
        }
        if (colors.isEmpty()) text.append("No document colors\n");
        editor.showScratchBuffer("[lsp document colors]", text.toString());
        return "Showing " + colors.size() + " document color" + (colors.size() == 1 ? "" : "s");
    }

    public String lspPullDiagnostics() {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) return "LSP pull diagnostics require a file-backed buffer";
        LspClient client = resolveLspClient(buffer);
        if (client == null) return "LSP unavailable";
        String unavailable = capabilityUnavailable(client, LspCapability.PULL_DIAGNOSTICS);
        if (unavailable != null) return unavailable;
        syncLspOpen(buffer);
        flushPendingLspChange(buffer);
        String uri = bufferUri(buffer);
        Integer version = editor.lspDocumentVersions.get(uri);
        List<LspClient.Diagnostic> diagnostics = client.pullDiagnostics(uri);
        if (!Objects.equals(version, editor.lspDocumentVersions.get(uri))) return "Pull diagnostics became stale; refresh again";
        if (diagnostics.isEmpty()) {
            editor.problemsController.clearQuickfixSource("diagnostics");
            return "No pull diagnostics";
        }
        List<QuickfixService.Entry> entries = diagnosticsToQuickfixEntries(buffer.getFilePath(), diagnostics);
        if (entries.isEmpty()) return "No pull diagnostics";
        editor.updateQuickfixEntries("pull diagnostics", entries);
        return editor.openQuickfixList();
    }

    public String lspWorkspaceDiagnostics() {
        FileBuffer active = editor.getCurrentBuffer();
        if (active != null && active.hasFilePath() && !active.isLargeFile()) {
            syncLspOpen(active);
            flushPendingLspChange(active);
        }
        List<LspClient> clients = new ArrayList<>(new LinkedHashSet<>(editor.lspClients.values()));
        clients.removeIf(client -> client == null || !client.isAlive() || !client.supports(LspCapability.WORKSPACE_DIAGNOSTICS));
        if (clients.isEmpty()) return "No LSP workspace diagnostic provider is active";
        List<QuickfixService.Entry> entries = new ArrayList<>();
        for (LspClient client : clients) {
            for (Map.Entry<String, List<LspClient.Diagnostic>> report : client.workspaceDiagnostics().entrySet()) {
                String path = filePathFromUri(report.getKey());
                if (path == null || path.isBlank()) continue;
                entries.addAll(diagnosticsToQuickfixEntries(path, report.getValue()));
            }
        }
        if (entries.isEmpty()) {
            editor.problemsController.clearQuickfixSource("workspace diagnostics");
            return "No workspace diagnostics";
        }
        editor.updateQuickfixEntries("workspace diagnostics", entries);
        return editor.openQuickfixList();
    }

    public String lspFoldingRanges() {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) return "LSP folding ranges require a file-backed buffer";
        LspClient client = resolveLspClient(buffer);
        if (client == null) return "LSP unavailable";
        String unavailable = capabilityUnavailable(client, LspCapability.FOLDING_RANGES);
        if (unavailable != null) return unavailable;
        syncLspOpen(buffer);
        flushPendingLspChange(buffer);
        String uri = bufferUri(buffer);
        Integer version = editor.lspDocumentVersions.get(uri);
        List<LspClient.FoldingRange> ranges = client.foldingRanges(uri);
        if (!Objects.equals(version, editor.lspDocumentVersions.get(uri))) return "Folding ranges became stale; refresh again";
        StringBuilder text = new StringBuilder("LSP Folding Ranges\n\n");
        for (LspClient.FoldingRange range : ranges) {
            text.append(range.startLine() + 1).append(":").append(range.startCharacter() < 0 ? 1 : range.startCharacter() + 1)
                .append("–").append(range.endLine() + 1).append(":").append(range.endCharacter() < 0 ? "end" : range.endCharacter() + 1);
            if (range.kind() != null && !range.kind().isBlank()) text.append("  ").append(editor.safePreviewText(range.kind(), 80));
            text.append('\n');
        }
        if (ranges.isEmpty()) text.append("No folding ranges\n");
        text.append("\nThese ranges are informational; the current editor fold model remains Markdown-heading-only.\n");
        editor.showScratchBuffer("[lsp folding ranges]", text.toString());
        return "Showing " + ranges.size() + " folding range" + (ranges.size() == 1 ? "" : "s");
    }

    public String lspFormat() {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) return "LSP formatting requires a file-backed buffer";
        LspClient client = resolveLspClient(buffer);
        if (client == null) return "LSP unavailable";
        String unavailable = capabilityUnavailable(client, LspCapability.FORMATTING);
        if (unavailable != null) return unavailable;
        syncLspOpen(buffer);
        String uri = bufferUri(buffer);
        Integer version = editor.lspDocumentVersions.get(uri);
        List<LspClient.TextEdit> edits = client.formatting(uri, editor.writingArea.getTabSize(), editor.effectiveExpandTab());
        if (!Objects.equals(version, editor.lspDocumentVersions.get(uri))) return "Formatting became stale; document was not changed";
        if (edits.isEmpty()) return "No formatting edits";
        WorkspaceEditApplyResult result = applyWorkspaceTextEdits(edits);
        if (result.appliedEditCount <= 0) return result.failureReason == null ? "Formatting produced no applicable edits" : "Formatting failed: " + result.failureReason;
        return "Applied " + result.appliedEditCount + " formatting edit" + (result.appliedEditCount == 1 ? "" : "s")
            + (result.recoveryNotice.isEmpty() ? "" : "; " + result.recoveryNotice);
    }


    public String lspReferences() {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath()) {
            return "LSP references requires a file-backed buffer";
        }
        LspClient client = resolveLspClient(buffer);
        if (client == null) {
            return "LSP unavailable";
        }
        String unavailable = capabilityUnavailable(client, LspCapability.REFERENCES);
        if (unavailable != null) return unavailable;
        syncLspOpen(buffer);
        String uri = bufferUri(buffer);
        try {
            int line = editor.writingArea.getLineOfOffset(editor.writingArea.getCaretPosition());
            int column = editor.writingArea.getCaretPosition() - editor.writingArea.getLineStartOffset(line);
            List<LspClient.Location> locations = client.references(uri, line, column, true);
            if (locations.isEmpty()) {
                editor.problemsController.clearQuickfixSource("lsp");
                return "No references found";
            }
            return showLspLocationsInQuickfix("references", locations);
        } catch (BadLocationException e) {
            return "LSP references failed: " + e.getMessage();
        }
    }

    private String showLspLocationsInQuickfix(String label, List<LspClient.Location> locations) {
        List<QuickfixService.Entry> entries = new ArrayList<>();
        for (LspClient.Location location : locations) {
            String path = filePathFromUri(location.getUri());
            if (path == null || path.isBlank()) continue;
            entries.add(new QuickfixService.Entry(path, location.getLine() + 1, location.getCharacter() + 1,
                label.substring(0, label.length() - (label.endsWith("s") ? 1 : 0)), "lsp"));
        }
        if (entries.isEmpty()) {
            editor.problemsController.clearQuickfixSource("lsp");
            return "No file " + label + " found";
        }
        editor.updateQuickfixEntries("lsp " + label, entries);
        return editor.openQuickfixList();
    }

    String showSymbols(String argument) {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) {
            return editor.showHeuristicSymbols(argument);
        }
        LspClient client = resolveLspClient(buffer);
        if (client == null || !client.supports(LspCapability.DOCUMENT_SYMBOLS)) {
            return editor.showHeuristicSymbols(argument);
        }
        syncLspOpen(buffer);
        String uri = bufferUri(buffer);
        int jobId = editor.asyncJobService.submit("lsp document symbols", token -> {
            if (token.isCancelled()) return List.<LspClient.NavigationSymbol>of();
            return client.documentSymbols(uri);
        }, (snapshot, symbols, error) -> {
            if (snapshot.getStatus() == AsyncJobService.Status.CANCELLED) return;
            if (error != null || symbols == null || symbols.isEmpty()) {
                editor.showHeuristicSymbols(argument);
                return;
            }
            editor.showLspSymbols(symbols, argument, false);
        });
        return "Loading document symbols (job " + jobId + ")";
    }

    String showWorkspaceSymbols(String argument) {
        String query = argument == null ? "" : argument.trim();
        if (query.isBlank() || query.indexOf('\0') >= 0 || query.indexOf('\n') >= 0 || query.indexOf('\r') >= 0) {
            return "Usage: :workspace symbols <query>";
        }
        int generation = ++workspaceSymbolQueryGeneration;
        workspaceSymbolCoordinator.cancel();
        FileBuffer active = editor.getCurrentBuffer();
        if (active != null && active.hasFilePath() && !active.isLargeFile()) syncLspOpen(active);
        List<LspClient> clients = new ArrayList<>(new LinkedHashSet<>(editor.lspClients.values()));
        clients.removeIf(client -> client == null || !client.isAlive() || !client.supports(LspCapability.WORKSPACE_SYMBOLS));
        if (clients.isEmpty()) return workspaceSymbolCoordinator.search(query);
        int jobId = editor.asyncJobService.submit("lsp workspace symbols", token -> collectWorkspaceSymbols(clients, query, token),
            (snapshot, symbols, error) -> {
                if (generation != workspaceSymbolQueryGeneration || snapshot.getStatus() == AsyncJobService.Status.CANCELLED) return;
                if (error != null || symbols == null || symbols.isEmpty()) {
                    String localStatus = workspaceSymbolCoordinator.search(query);
                    String reason = error == null ? "No LSP workspace symbols found" : "LSP workspace-symbol search failed: " + error.getMessage();
                    editor.showMessage(reason + "; " + localStatus);
                    return;
                }
                editor.showLspSymbols(symbols, query, true);
            });
        return "Loading workspace symbols (job " + jobId + ")";
    }

    private List<LspClient.NavigationSymbol> collectWorkspaceSymbols(List<LspClient> clients, String query, AsyncJobService.JobToken token) {
        Map<String, LspClient.NavigationSymbol> unique = Collections.synchronizedMap(new LinkedHashMap<>());
        clients.parallelStream().forEach(client -> {
            if (token.isCancelled()) return;
            for (LspClient.NavigationSymbol symbol : client.workspaceSymbols(query)) {
                if (token.isCancelled()) return;
                String key = symbol.getUri() + "\u0000" + symbol.getLine() + "\u0000" + symbol.getCharacter() + "\u0000" + symbol.getName();
                unique.putIfAbsent(key, symbol);
            }
        });
        List<LspClient.NavigationSymbol> result = new ArrayList<>(unique.values());
        result.sort(Comparator.comparing(LspClient.NavigationSymbol::getName, String.CASE_INSENSITIVE_ORDER)
            .thenComparing(LspClient.NavigationSymbol::getUri, String.CASE_INSENSITIVE_ORDER)
            .thenComparingInt(LspClient.NavigationSymbol::getLine));
        return result.size() <= 300 ? result : new ArrayList<>(result.subList(0, 300));
    }

    String openLspSymbol(LspClient.NavigationSymbol symbol) {
        if (symbol == null) return "No symbol selected";
        return openLspLocation(new LspClient.Location(symbol.getUri(), symbol.getLine(), symbol.getCharacter()), "symbol");
    }


    public String lspRename(String newName) {
        if (newName == null || newName.isBlank()) {
            return "Usage: :lsp rename <newName>";
        }
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath()) {
            return "LSP rename requires a file-backed buffer";
        }
        LspClient client = resolveLspClient(buffer);
        if (client == null) {
            return "LSP unavailable";
        }
        String unavailable = capabilityUnavailable(client, LspCapability.RENAME);
        if (unavailable != null) return unavailable;
        syncLspOpen(buffer);
        String uri = bufferUri(buffer);
        try {
            int line = editor.writingArea.getLineOfOffset(editor.writingArea.getCaretPosition());
            int column = editor.writingArea.getCaretPosition() - editor.writingArea.getLineStartOffset(line);
            List<LspClient.TextEdit> edits = client.rename(uri, line, column, newName.trim());
            if (edits.isEmpty()) {
                return "No rename edits returned";
            }
            editor.pendingLspRenameEdits = new ArrayList<>(edits);
            editor.pendingLspRenameTarget = newName.trim();
            editor.showScratchBuffer("[lsp rename preview]", buildLspRenamePreview(editor.pendingLspRenameTarget, editor.pendingLspRenameEdits));
            return "Prepared rename preview (" + edits.size() + " edit" + (edits.size() == 1 ? "" : "s") + "). Run :lsp renameapply to confirm.";
        } catch (BadLocationException e) {
            return "LSP rename failed: " + e.getMessage();
        }
    }


    public String lspRenameApply() {
        if (editor.pendingLspRenameEdits == null || editor.pendingLspRenameEdits.isEmpty()) {
            return "No pending rename preview (run :lsp rename <newName> first)";
        }
        WorkspaceEditApplyResult applyResult = applyWorkspaceTextEdits(editor.pendingLspRenameEdits);
        if (applyResult.appliedEditCount <= 0) {
            editor.pendingLspRenameEdits = null;
            editor.pendingLspRenameTarget = null;
            return applyResult.failureReason == null || applyResult.failureReason.isBlank()
                ? "Pending rename had no applicable edits" : "Rename failed: " + applyResult.failureReason;
        }
        StringBuilder message = new StringBuilder();
        message.append("Applied ")
            .append(applyResult.appliedEditCount)
            .append(" rename edit")
            .append(applyResult.appliedEditCount == 1 ? "" : "s")
            .append(" across ")
            .append(applyResult.touchedFiles)
            .append(" file")
            .append(applyResult.touchedFiles == 1 ? "" : "s");
        if (applyResult.failedFiles > 0) {
            message.append(" (").append(applyResult.failedFiles).append(" file failures)");
        }
        if (!applyResult.recoveryNotice.isEmpty()) message.append("; ").append(applyResult.recoveryNotice);
        editor.pendingLspRenameEdits = null;
        editor.pendingLspRenameTarget = null;
        return message.toString();
    }


    public String lspRenameCancel() {
        editor.pendingLspRenameEdits = null;
        editor.pendingLspRenameTarget = null;
        return "Cleared pending rename preview";
    }


    String buildLspRenamePreview(String targetName, List<LspClient.TextEdit> edits) {
        StringBuilder builder = new StringBuilder();
        builder.append("LSP Rename Preview\n");
        builder.append("=".repeat(40)).append("\n\n");
        builder.append("Target name: ").append(targetName == null ? "" : targetName).append("\n");
        builder.append("Total edits: ").append(edits == null ? 0 : edits.size()).append("\n\n");
        if (edits == null || edits.isEmpty()) {
            builder.append("(no edits)\n");
            return builder.toString();
        }
        Map<String, List<LspClient.TextEdit>> byFile = new LinkedHashMap<>();
        for (LspClient.TextEdit edit : edits) {
            String path = filePathFromUri(edit.getUri());
            if (path == null || path.isBlank()) {
                path = edit.getUri();
            }
            byFile.computeIfAbsent(path, key -> new ArrayList<>()).add(edit);
        }
        for (Map.Entry<String, List<LspClient.TextEdit>> entry : byFile.entrySet()) {
            builder.append(entry.getKey()).append("\n");
            List<LspClient.TextEdit> fileEdits = entry.getValue();
            fileEdits.sort((a, b) -> {
                if (a.getStartLine() != b.getStartLine()) {
                    return Integer.compare(a.getStartLine(), b.getStartLine());
                }
                return Integer.compare(a.getStartCharacter(), b.getStartCharacter());
            });
            int limit = Math.min(8, fileEdits.size());
            for (int i = 0; i < limit; i++) {
                LspClient.TextEdit edit = fileEdits.get(i);
                builder.append("  - ")
                    .append(edit.getStartLine() + 1)
                    .append(":")
                    .append(edit.getStartCharacter() + 1)
                    .append(" -> ")
                    .append(editor.safePreviewText(edit.getNewText(), 60))
                    .append("\n");
            }
            if (fileEdits.size() > limit) {
                builder.append("  ... ").append(fileEdits.size() - limit).append(" more edits\n");
            }
            builder.append("\n");
        }
        builder.append("Run :lsp renameapply to apply, or :lsp renamecancel to discard.\n");
        return builder.toString();
    }


    public String lspCodeActions(String selectionArgument) {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath()) {
            return "LSP code actions require a file-backed buffer";
        }
        LspClient client = resolveLspClient(buffer);
        if (client == null) {
            return "LSP unavailable";
        }
        String unavailable = capabilityUnavailable(client, LspCapability.CODE_ACTION);
        if (unavailable != null) return unavailable;
        int requestedIndex = parseOneBasedIndex(selectionArgument);
        if (selectionArgument != null && !selectionArgument.isBlank() && requestedIndex < 1) return "Usage: :lsp codeaction [index]";
        syncLspOpen(buffer);
        flushPendingLspChange(buffer);
        String uri = bufferUri(buffer);
        try {
            int caret = editor.writingArea.getCaretPosition();
            int line = editor.writingArea.getLineOfOffset(caret);
            int column = caret - editor.writingArea.getLineStartOffset(line);
            List<LspClient.Diagnostic> diagnostics = collectCursorDiagnostics(client, uri, line, column);
            if (diagnostics.isEmpty()) return "No diagnostic at caret";
            long generation = ++codeActionGeneration;
            if (codeActionJobId >= 0) editor.asyncJobService.cancel(codeActionJobId);
            CodeActionRequest request = new CodeActionRequest(buffer, client, uri, editor.lspDocumentVersions.get(uri), caret, line, column,
                List.copyOf(diagnostics), requestedIndex, generation);
            codeActionJobId = editor.asyncJobService.submit("LSP code actions", token -> new CodeActionResult(request,
                client.codeActions(uri, line, column, request.diagnostics())), this::completeCodeActions);
            return "Loading code actions…";
        } catch (BadLocationException e) {
            return "LSP code actions failed: " + e.getMessage();
        }
    }

    private void completeCodeActions(AsyncJobService.JobSnapshot job, CodeActionResult result, Exception error) {
        if (result == null || result.request().generation() != codeActionGeneration) return;
        codeActionJobId = -1;
        if (job.getStatus() == AsyncJobService.Status.CANCELLED) return;
        if (error != null) { editor.showMessage("Code actions failed: " + error.getMessage()); return; }
        CodeActionRequest request = result.request();
        if (editor.getCurrentBuffer() != request.buffer() || !Objects.equals(editor.lspDocumentVersions.get(request.uri()), request.version())
            || editor.writingArea.getCaretPosition() != request.caretOffset()) {
            editor.showMessage("Code actions became stale");
            return;
        }
        List<LspClient.CodeAction> actions = result.actions() == null ? List.of() : result.actions();
        if (actions.isEmpty()) { editor.showMessage("No code actions"); return; }
        if (request.requestedIndex() > 0) {
            if (request.requestedIndex() > actions.size()) { editor.showMessage("Code action index out of range: " + request.requestedIndex()); return; }
            prepareCodeActionPreview(actions.get(request.requestedIndex() - 1));
            return;
        }
        showCodeActionPicker(actions);
    }

    private void showCodeActionPicker(List<LspClient.CodeAction> actions) {
        JPopupMenu popup = new JPopupMenu();
        popup.setBorder(BorderFactory.createLineBorder(editor.configManager.getSelectionColor()));
        for (LspClient.CodeAction action : actions) {
            String label = action.getTitle() + (action.isPreferred() ? "  ★" : "");
            JMenuItem item = new JMenuItem(label);
            item.setFont(editor.resolveUiFont());
            item.addActionListener(event -> prepareCodeActionPreview(action));
            popup.add(item);
        }
        editor.editorUiController.applyUiTheme(popup);
        try {
            java.awt.Rectangle bounds = editor.writingArea.modelToView2D(editor.writingArea.getCaretPosition()).getBounds();
            popup.show(editor.writingArea, bounds.x, bounds.y + bounds.height);
        } catch (BadLocationException error) {
            editor.showMessage("Code action picker failed: " + error.getMessage());
        }
    }

    private void prepareCodeActionPreview(LspClient.CodeAction action) {
        editor.pendingLspCodeAction = action;
        ShedInformationDialog.showFor(editor, "Code Action Preview", buildWorkspaceEditPreview(action.getTitle(), action.getOperations(), new WorkspaceEditApplyResult())
            + "\nReview the edits before applying this code action.\n", "Apply code action",
            () -> editor.showMessage(lspCodeActionApply()));
        editor.showMessage("Prepared code action preview. Run :lsp codeaction apply to confirm.");
    }

    public String lspCodeActionApply() {
        LspClient.CodeAction action = editor.pendingLspCodeAction;
        if (action == null) return "No pending code action preview";
        WorkspaceEditApplyResult applyResult = applyWorkspaceOperations(action.getOperations());
        editor.pendingLspCodeAction = null;
        if (applyResult.appliedEditCount == 0 && applyResult.appliedResourceOperationCount == 0) {
            return applyResult.failureReason == null || applyResult.failureReason.isBlank() ? "Code action produced no applicable edit" : "Code action failed: " + applyResult.failureReason;
        }
        return "Applied code action: " + action.getTitle()
            + (applyResult.recoveryNotice.isEmpty() ? "" : "; " + applyResult.recoveryNotice);
    }


    List<LspClient.CodeAction> collectCursorCodeActions(LspClient client, String uri, int line, int column) {
        return client.codeActions(uri, line, column, collectCursorDiagnostics(client, uri, line, column));
    }

    List<LspClient.Diagnostic> collectCursorDiagnostics(LspClient client, String uri, int line, int column) {
        List<LspClient.Diagnostic> scoped = new ArrayList<>();
        for (LspClient.Diagnostic diagnostic : client.getDiagnostics(uri)) {
            if (contains(diagnostic, line, column)) scoped.add(diagnostic);
        }
        return scoped;
    }

    private static boolean contains(LspClient.Diagnostic diagnostic, int line, int column) {
        if (diagnostic == null) return false;
        int startLine = diagnostic.getLine();
        int startColumn = diagnostic.getCharacter();
        int endLine = diagnostic.getEndLine();
        int endColumn = diagnostic.getEndCharacter();
        if (line < startLine || line > endLine) return false;
        if (startLine == endLine) return line == startLine && column >= startColumn && column <= Math.max(startColumn, endColumn);
        if (line == startLine) return column >= startColumn;
        if (line == endLine) return column <= endColumn;
        return true;
    }

    private String capabilityUnavailable(LspClient client, LspCapability capability) {
        return client.supports(capability) ? null : client.capabilityUnavailableReason(capability);
    }


    int parseOneBasedIndex(String value) {
        if (value == null || value.isBlank()) {
            return -1;
        }
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }


    public String showDiagnostics() {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath()) {
            return "Diagnostics require a file-backed buffer";
        }
        LspClient client = resolveLspClient(buffer);
        if (client == null) {
            return "LSP unavailable";
        }
        syncLspOpen(buffer);
        List<LspClient.Diagnostic> diagnostics = client.getDiagnostics(bufferUri(buffer));
        if (diagnostics.isEmpty()) {
            return "No diagnostics";
        }
        List<QuickfixService.Entry> entries = diagnosticsToQuickfixEntries(buffer.getFilePath(), diagnostics);
        if (entries.isEmpty()) {
            return "No diagnostics";
        }
        editor.updateQuickfixEntries("diagnostics", entries);
        return editor.openQuickfixList();
    }


    public String diagnosticsNext() {
        return jumpDiagnostic(true);
    }


    public String diagnosticsPrev() {
        return jumpDiagnostic(false);
    }


    String jumpDiagnostic(boolean forward) {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath()) {
            return "Diagnostics require a file-backed buffer";
        }
        LspClient client = resolveLspClient(buffer);
        if (client == null) {
            return "LSP unavailable";
        }
        syncLspOpen(buffer);
        List<LspClient.Diagnostic> diagnostics = new ArrayList<>(client.getDiagnostics(bufferUri(buffer)));
        if (diagnostics.isEmpty()) {
            return "No diagnostics";
        }
        diagnostics.sort((left, right) -> {
            if (left.getLine() != right.getLine()) {
                return Integer.compare(left.getLine(), right.getLine());
            }
            return Integer.compare(left.getCharacter(), right.getCharacter());
        });
        int caretLine = editor.getCurrentCaretLine();
        LspClient.Diagnostic selected = null;
        if (forward) {
            for (LspClient.Diagnostic diagnostic : diagnostics) {
                if (diagnostic.getLine() > caretLine) {
                    selected = diagnostic;
                    break;
                }
            }
            if (selected == null) {
                selected = diagnostics.get(0);
            }
        } else {
            for (int i = diagnostics.size() - 1; i >= 0; i--) {
                LspClient.Diagnostic diagnostic = diagnostics.get(i);
                if (diagnostic.getLine() < caretLine) {
                    selected = diagnostic;
                    break;
                }
            }
            if (selected == null) {
                selected = diagnostics.get(diagnostics.size() - 1);
            }
        }
        if (selected == null) {
            return "No diagnostics";
        }
        try {
            int line = Math.max(0, Math.min(selected.getLine(), editor.writingArea.getLineCount() - 1));
            int start = editor.writingArea.getLineStartOffset(line);
            int target = Math.min(start + Math.max(0, selected.getCharacter()), editor.writingArea.getText().length());
            editor.writingArea.setCaretPosition(target);
            return diagnosticSeverityLabel(selected.getSeverity()) + ": " + selected.getMessage();
        } catch (BadLocationException e) {
            return "Diagnostic jump failed: " + e.getMessage();
        }
    }


    List<QuickfixService.Entry> diagnosticsToQuickfixEntries(String filePath, List<LspClient.Diagnostic> diagnostics) {
        List<QuickfixService.Entry> entries = new ArrayList<>();
        if (filePath == null || diagnostics == null) {
            return entries;
        }
        for (LspClient.Diagnostic diagnostic : diagnostics) {
            if (diagnostic == null) {
                continue;
            }
            entries.add(new QuickfixService.Entry(
                filePath,
                diagnostic.getLine() + 1,
                diagnostic.getCharacter() + 1,
                diagnostic.getMessage(),
                "diag-" + diagnosticSeverityLabel(diagnostic.getSeverity()).toLowerCase()
            ));
        }
        return entries;
    }


    String diagnosticSeverityLabel(int severity) {
        switch (severity) {
            case 1:
                return "Error";
            case 2:
                return "Warning";
            case 3:
                return "Info";
            case 4:
                return "Hint";
            default:
                return "Diag";
        }
    }


    String openLspLocation(LspClient.Location location, String label) {
        String targetPath = filePathFromUri(location.getUri());
        if (targetPath == null || targetPath.isBlank()) {
            return "LSP " + label + " target has unsupported URI";
        }
        File targetFile = new File(targetPath);
        if (!targetFile.exists()) return "LSP " + label + " target missing: " + targetPath;
        editor.recordJumpPosition();
        editor.openFileAtAsync(targetFile, location.getLine() + 1, location.getCharacter() + 1,
            "Opened " + label + " location");
        return "Opening " + label + " location";
    }

    WorkspaceEditApplyResult applyWorkspaceTextEdits(List<LspClient.TextEdit> edits) {
        if (edits == null || edits.isEmpty()) {
            return new WorkspaceEditApplyResult();
        }
        List<LspClient.WorkspaceEditOperation> operations = new ArrayList<>();
        for (LspClient.TextEdit edit : edits) {
            if (edit != null) {
                operations.add(LspClient.WorkspaceEditOperation.textEdit(edit));
            }
        }
        return applyWorkspaceOperations(operations);
    }


    LspClient.WorkspaceEditResponse applyWorkspaceEditFromServer(String label, List<LspClient.WorkspaceEditOperation> operations) {
        return requestWorkspaceEditReview(() -> {
            if (!editor.closingDown) ShedInformationDialog.showFor(editor, "Workspace Edit Review",
                buildWorkspaceEditPreview(label, operations, new WorkspaceEditApplyResult())
                    + "\nServer-originated workspace edits require review and were not applied.\n");
        });
    }

    static LspClient.WorkspaceEditResponse requestWorkspaceEditReview(Runnable review) {
        if (SwingUtilities.isEventDispatchThread()) review.run();
        else SwingUtilities.invokeLater(review);
        return new LspClient.WorkspaceEditResponse(false, "workspace edit requires user review");
    }


    WorkspaceEditApplyResult applyWorkspaceOperations(List<LspClient.WorkspaceEditOperation> operations) {
        WorkspaceEditApplyResult result = new WorkspaceEditApplyResult();
        if (operations == null || operations.isEmpty()) {
            return result;
        }
        WorkspaceEditPlan plan = buildWorkspaceEditPlan(operations, result);
        if (plan == null || result.failedFiles > 0) {
            if (result.failureReason == null || result.failureReason.isBlank()) {
                result.failureReason = "workspace edit preflight failed";
            }
            return result;
        }
        WorkspaceEditTransaction transaction = new WorkspaceEditTransaction();
        try {
            for (Map.Entry<Path, String> expected : plan.diskVersions.entrySet()) {
                var current = WorkspaceTextFile.capture(WorkspacePaths.id(expected.getKey().getParent()), expected.getKey(), true);
                if (!expected.getValue().equals(current.document().version())) throw new IOException("File changed since preflight: " + expected.getKey());
            }
            List<StagedTextWrite> stagedWrites = prepareStagedTextWrites(plan, transaction);
            applyResourceActions(plan.resourceActions, transaction);
            applyStagedTextWrites(stagedWrites, transaction);
            transaction.commit();
            result.appliedEditCount = plan.appliedEditCount;
            result.appliedResourceOperationCount = plan.resourceActions.size();
            result.touchedFiles = plan.touchedPaths.size();
        } catch (IOException | RuntimeException e) {
            transaction.rollback();
            result.failedFiles++;
            result.failureReason = e.getMessage();
        } finally {
            WorkspaceEditTransaction.Report report = transaction.cleanup();
            result.recoveryNotice = report.notice();
            if (!result.recoveryNotice.isEmpty() && result.failedFiles > 0)
                result.failureReason = Objects.toString(result.failureReason, "Workspace edit failed") + "; " + result.recoveryNotice;
        }
        return result;
    }


    WorkspaceEditPlan buildWorkspaceEditPlan(List<LspClient.WorkspaceEditOperation> operations, WorkspaceEditApplyResult result) {
        WorkspaceEditPlan plan = new WorkspaceEditPlan();
        for (int i = 0; i < operations.size(); i++) {
            LspClient.WorkspaceEditOperation operation = operations.get(i);
            if (operation == null || operation.getKind() == null) {
                continue;
            }
            switch (operation.getKind()) {
                case TEXT_EDIT: {
                    List<LspClient.TextEdit> group = new ArrayList<>();
                    LspClient.TextEdit first = operation.getTextEdit();
                    if (first == null || first.getUri() == null || first.getUri().isBlank()) {
                        failWorkspacePreflight(result, "text edit missing uri");
                        return null;
                    }
                    group.add(first);
                    while (i + 1 < operations.size() && sameTextEditTarget(first, operations.get(i + 1))) {
                        i++;
                        group.add(operations.get(i).getTextEdit());
                    }
                    Path path = workspacePathFromUri(first.getUri());
                    if (path == null) {
                        failWorkspacePreflight(result, "text edit outside workspace: " + first.getUri());
                        return null;
                    }
                    if (hasWorkspaceEditVersionConflict(first.getUri(), group)) {
                        failWorkspacePreflight(result, "stale document version: " + first.getUri());
                        return null;
                    }
                    String pathKey = path.toString();
                    String currentText = plan.stagedTextByPath.containsKey(pathKey)
                        ? plan.stagedTextByPath.get(pathKey)
                        : readWorkspaceTextForEdit(path, plan);
                    if (currentText == null) {
                        failWorkspacePreflight(result, "text edit target missing: " + path);
                        return null;
                    }
                    List<ResolvedTextEdit> resolved = resolveTextEdits(currentText, group);
                    if (resolved.isEmpty()) {
                        failWorkspacePreflight(result, "text edit target had no applicable edits: " + path);
                        return null;
                    }
                    plan.stagedTextByPath.put(pathKey, applyResolvedTextEdits(currentText, resolved));
                    plan.touchedPaths.add(pathKey);
                    plan.appliedEditCount += resolved.size();
                    break;
                }
                case CREATE: {
                    Path path = workspacePathFromUri(operation.getUri());
                    if (path == null) {
                        failWorkspacePreflight(result, "create outside workspace: " + operation.getUri());
                        return null;
                    }
                    String pathKey = path.toString();
                    boolean exists = Files.exists(path) || plan.stagedTextByPath.containsKey(pathKey);
                    if (Files.isDirectory(path)) {
                        failWorkspacePreflight(result, "create target is directory: " + path);
                        return null;
                    }
                    if (exists && !operation.isOverwrite() && !operation.isIgnoreIfExists()) {
                        failWorkspacePreflight(result, "create target exists: " + path);
                        return null;
                    }
                    if (!exists || operation.isOverwrite()) {
                        plan.stagedTextByPath.put(pathKey, "");
                        plan.resourceActions.add(ResourceAction.create(path, operation.isOverwrite()));
                        plan.touchedPaths.add(pathKey);
                    }
                    break;
                }
                case RENAME: {
                    Path oldPath = workspacePathFromUri(operation.getOldUri());
                    Path newPath = workspacePathFromUri(operation.getNewUri());
                    if (oldPath == null || newPath == null) {
                        failWorkspacePreflight(result, "rename outside workspace");
                        return null;
                    }
                    String oldKey = oldPath.toString();
                    String newKey = newPath.toString();
                    boolean oldExists = Files.exists(oldPath) || plan.stagedTextByPath.containsKey(oldKey);
                    boolean newExists = Files.exists(newPath) || plan.stagedTextByPath.containsKey(newKey);
                    if (!oldExists) {
                        failWorkspacePreflight(result, "rename source missing: " + oldPath);
                        return null;
                    }
                    if (newExists && !operation.isOverwrite() && !operation.isIgnoreIfExists()) {
                        failWorkspacePreflight(result, "rename target exists: " + newPath);
                        return null;
                    }
                    if (!newExists || operation.isOverwrite()) {
                        if (plan.stagedTextByPath.containsKey(oldKey)) {
                            plan.stagedTextByPath.put(newKey, plan.stagedTextByPath.remove(oldKey));
                        } else if (Files.isRegularFile(oldPath)) {
                            String original = readWorkspaceTextForEdit(oldPath, plan);
                            // Resource-only renames also support binary/non-text files.
                            if (original != null) plan.stagedTextByPath.put(newKey, original);
                        }
                        if (plan.diskImages.containsKey(oldKey)) plan.diskImages.put(newKey, plan.diskImages.remove(oldKey));
                        plan.resourceActions.add(ResourceAction.rename(oldPath, newPath, operation.isOverwrite()));
                        plan.touchedPaths.add(oldKey);
                        plan.touchedPaths.add(newKey);
                    }
                    break;
                }
                case DELETE: {
                    Path path = workspacePathFromUri(operation.getUri());
                    if (path == null) {
                        failWorkspacePreflight(result, "delete outside workspace: " + operation.getUri());
                        return null;
                    }
                    String pathKey = path.toString();
                    boolean exists = Files.exists(path) || plan.stagedTextByPath.containsKey(pathKey);
                    if (!exists && operation.isIgnoreIfNotExists()) {
                        break;
                    }
                    if (!exists) {
                        failWorkspacePreflight(result, "delete target missing: " + path);
                        return null;
                    }
                    if (Files.isDirectory(path) && !operation.isRecursive()) {
                        failWorkspacePreflight(result, "delete target is directory: " + path);
                        return null;
                    }
                    plan.stagedTextByPath.remove(pathKey);
                    plan.resourceActions.add(ResourceAction.delete(path, operation.isRecursive()));
                    plan.touchedPaths.add(pathKey);
                    break;
                }
            }
        }
        return plan;
    }


    private void failWorkspacePreflight(WorkspaceEditApplyResult result, String reason) {
        result.failedFiles++;
        result.failureReason = reason == null ? "workspace edit preflight failed" : reason;
    }


    private boolean sameTextEditTarget(LspClient.TextEdit first, LspClient.WorkspaceEditOperation operation) {
        if (first == null || operation == null || operation.getKind() != LspClient.WorkspaceEditOperation.Kind.TEXT_EDIT) {
            return false;
        }
        LspClient.TextEdit next = operation.getTextEdit();
        if (next == null) {
            return false;
        }
        return Objects.equals(first.getUri(), next.getUri())
            && Objects.equals(first.getDocumentVersion(), next.getDocumentVersion());
    }


    private String readWorkspaceTextForEdit(Path path, WorkspaceEditPlan plan) {
        if (editor != null) {
            FileBuffer buffer = editor.findBufferByPath(path.toFile());
            if (buffer != null) {
                return buffer == editor.getCurrentBuffer() ? editor.writingArea.getText() : buffer.getContent();
            }
        }
        if (!Files.isRegularFile(path)) {
            return null;
        }
        try {
            var snapshot = WorkspaceTextFile.capture(WorkspacePaths.id(path.getParent()), path, true);
            plan.diskImages.put(path.toString(), snapshot.image());
            plan.diskVersions.put(path, snapshot.document().version());
            return snapshot.document().content();
        } catch (WorkspaceApiException e) {
            return null;
        }
    }


    private void applyResourceActions(List<ResourceAction> actions, WorkspaceEditTransaction transaction) throws IOException {
        for (ResourceAction action : actions) {
            switch (action.kind) {
                case CREATE:
                    // New-file content and parent directories are already staged by the transaction.
                    break;
                case RENAME:
                    renameWorkspaceFile(action.path, action.targetPath, action.overwrite, transaction);
                    break;
                case DELETE:
                    deleteWorkspacePath(action.path, action.recursive, transaction);
                    break;
            }
        }
    }


    private void renameWorkspaceFile(Path oldPath, Path newPath, boolean overwrite, WorkspaceEditTransaction transaction) throws IOException {
        FileBuffer buffer = editor == null ? null : editor.findBufferByPath(oldPath.toFile());
        transaction.rename(oldPath, newPath, overwrite);
        if (buffer != null) transaction.addRollback("restore buffer path " + oldPath, () -> buffer.retargetFile(oldPath.toFile()));
        if (buffer != null) {
            buffer.retargetFile(newPath.toFile());
        }
    }


    private void deleteWorkspacePath(Path path, boolean recursive, WorkspaceEditTransaction transaction) throws IOException {
        FileBuffer buffer = editor == null ? null : editor.findBufferByPath(path.toFile());
        transaction.delete(path);
        if (buffer != null) {
            transaction.addCommit(() -> removeDeletedBuffer(buffer));
        }
    }


    private List<StagedTextWrite> prepareStagedTextWrites(WorkspaceEditPlan plan, WorkspaceEditTransaction transaction) throws IOException {
        List<StagedTextWrite> writes = new ArrayList<>();
        for (Map.Entry<String, String> entry : plan.stagedTextByPath.entrySet()) {
            Path path = Path.of(entry.getKey());
            TextFileCodec.Image image = plan.diskImages.get(entry.getKey());
            byte[] bytes = image == null ? TextFileCodec.encodeRaw(entry.getValue(), "UTF-8", false) : image.encode(entry.getValue());
            Path temp = transaction.stage(path, bytes);
            writes.add(new StagedTextWrite(path, entry.getValue(), temp));
        }
        return writes;
    }


    private void applyStagedTextWrites(List<StagedTextWrite> writes, WorkspaceEditTransaction transaction) throws IOException {
        for (StagedTextWrite write : writes) {
            FileBuffer buffer = editor == null ? null : editor.findBufferByPath(write.path.toFile());
            if (buffer != null) {
                applyStagedTextToBuffer(buffer, write.text, transaction);
            } else {
                writeFileAtomically(write.path, write.tempPath, transaction);
            }
        }
    }


    private void applyStagedTextToBuffer(FileBuffer buffer, String text, WorkspaceEditTransaction transaction) {
        String oldText = buffer == editor.getCurrentBuffer() ? editor.writingArea.getText() : buffer.getContent();
        boolean oldModified = buffer.isModified();
        transaction.addRollback(() -> restoreBufferText(buffer, oldText, oldModified));
        if (buffer == editor.getCurrentBuffer()) {
            editor.writingArea.setText(text == null ? "" : text);
            editor.markModified();
        } else {
            buffer.setContent(text == null ? "" : text, true);
        }
    }


    private void restoreBufferText(FileBuffer buffer, String text, boolean modified) {
        if (buffer == editor.getCurrentBuffer()) {
            editor.writingArea.setText(text == null ? "" : text);
            buffer.setModified(modified);
            editor.updateStatusBar();
        } else {
            buffer.setContent(text == null ? "" : text, modified);
        }
    }


    private void writeFileAtomically(Path path, Path temp, WorkspaceEditTransaction transaction) throws IOException {
        transaction.replace(path, temp);
    }


    private void removeDeletedBuffer(FileBuffer buffer) {
        if (buffer == null) {
            return;
        }
        boolean wasCurrent = buffer == editor.getCurrentBuffer();
        editor.buffers.remove(buffer);
        editor.releaseClosedBufferResources(buffer);
        if (wasCurrent && !editor.buffers.isEmpty()) {
            editor.switchToBuffer(Math.min(editor.currentBufferIndex, editor.buffers.size() - 1));
        } else if (editor.buffers.isEmpty()) {
            FileBuffer scratch = FileBuffer.createScratch("[No Name]", "");
            editor.buffers.add(scratch);
            editor.switchToBuffer(0);
        }
    }


    private Path workspacePathFromUri(String uri) {
        String filePath = filePathFromUri(uri);
        if (filePath == null || filePath.isBlank()) {
            return null;
        }
        try {
            Path candidate = Path.of(filePath).toAbsolutePath().normalize();
            Path root = editor == null ? resolveWorkspaceRoot(candidate.getParent()) : workspaceRootPath(editor.getCurrentBuffer());
            if (!candidate.startsWith(root)) {
                return null;
            }
            if (Files.exists(candidate)) {
                Path real = candidate.toRealPath();
                if (!real.startsWith(root)) {
                    return null;
                }
            }
            return candidate;
        } catch (IOException | RuntimeException e) {
            return null;
        }
    }


    private Path workspaceRootPath(FileBuffer buffer) throws IOException {
        if (buffer != null && buffer.hasFilePath()) {
            File file = new File(buffer.getFilePath());
            return resolveWorkspaceRoot(file.isDirectory() ? file.toPath() : file.toPath().getParent());
        }
        return resolveWorkspaceRoot(new File(".").getCanonicalFile().toPath());
    }

    Path resolveWorkspaceRoot(Path start) throws IOException {
        Path current = start == null
            ? new File(".").getCanonicalFile().toPath()
            : start.toAbsolutePath().normalize();
        if (Files.isRegularFile(current)) {
            current = current.getParent();
        }
        Path configured = editor == null || editor.workspaceController == null ? null
            : WorkspaceRootResolver.configuredRoot(current, editor.workspaceController.roots());
        if (configured != null) {
            return configured.toRealPath();
        }
        for (Path candidate = current; candidate != null; candidate = candidate.getParent()) {
            if (hasGitMetadata(candidate)
                || Files.exists(candidate.resolve("pom.xml"))
                || Files.exists(candidate.resolve("package.json"))
                || Files.exists(candidate.resolve("Makefile"))) {
                return candidate.toRealPath();
            }
        }
        return Files.exists(current) ? current.toRealPath() : current;
    }

    private static boolean hasGitMetadata(Path directory) {
        Path git = directory.resolve(".git");
        if (Files.isDirectory(git)) {
            return Files.isRegularFile(git.resolve("HEAD"));
        }
        try {
            if (!Files.isRegularFile(git) || Files.size(git) > 4096L) {
                return false;
            }
            String pointer = Files.readString(git, StandardCharsets.UTF_8).stripLeading();
            return pointer.startsWith("gitdir:");
        } catch (IOException | SecurityException ignored) {
            return false;
        }
    }


    boolean hasResourceOperation(List<LspClient.WorkspaceEditOperation> operations) {
        if (operations == null) {
            return false;
        }
        for (LspClient.WorkspaceEditOperation operation : operations) {
            if (operation != null && operation.getKind() != LspClient.WorkspaceEditOperation.Kind.TEXT_EDIT) {
                return true;
            }
        }
        return false;
    }


    String buildWorkspaceEditPreview(String label, List<LspClient.WorkspaceEditOperation> operations, WorkspaceEditApplyResult result) {
        StringBuilder builder = new StringBuilder();
        builder.append("LSP Workspace Edit\n");
        builder.append("=".repeat(40)).append("\n\n");
        if (label != null && !label.isBlank()) {
            builder.append("Label: ").append(label).append("\n");
        }
        builder.append("Applied text edits: ").append(result == null ? 0 : result.appliedEditCount).append("\n");
        builder.append("Applied resource ops: ").append(result == null ? 0 : result.appliedResourceOperationCount).append("\n");
        if (result != null && result.failureReason != null && !result.failureReason.isBlank()) {
            builder.append("Failure: ").append(result.failureReason).append("\n");
        }
        builder.append("\n");
        if (operations != null) {
            for (LspClient.WorkspaceEditOperation operation : operations) {
                if (operation == null) {
                    continue;
                }
                switch (operation.getKind()) {
                    case CREATE:
                        builder.append("create ").append(filePathFromUri(operation.getUri())).append("\n");
                        break;
                    case RENAME:
                        builder.append("rename ").append(filePathFromUri(operation.getOldUri())).append(" -> ").append(filePathFromUri(operation.getNewUri())).append("\n");
                        break;
                    case DELETE:
                        builder.append("delete ").append(filePathFromUri(operation.getUri())).append("\n");
                        break;
                    case TEXT_EDIT:
                        LspClient.TextEdit edit = operation.getTextEdit();
                        if (edit != null) {
                            builder.append("edit ").append(filePathFromUri(edit.getUri())).append(":")
                                .append(edit.getStartLine() + 1).append(":").append(edit.getStartCharacter() + 1)
                                .append(" -> ").append(editor.safePreviewText(edit.getNewText(), 60)).append("\n");
                        }
                        break;
                }
            }
        }
        return builder.toString();
    }


    boolean hasWorkspaceEditVersionConflict(String uri, List<LspClient.TextEdit> edits) {
        if (uri == null || edits == null || edits.isEmpty()) {
            return false;
        }
        if (editor == null || editor.lspDocumentVersions == null) {
            return false;
        }
        Integer currentVersion = editor.lspDocumentVersions.get(uri);
        if (currentVersion == null) {
            return false;
        }
        for (LspClient.TextEdit edit : edits) {
            Integer expectedVersion = edit == null ? null : edit.getDocumentVersion();
            if (expectedVersion != null && !expectedVersion.equals(currentVersion)) {
                return true;
            }
        }
        return false;
    }


    String applyResolvedTextEdits(String text, List<ResolvedTextEdit> resolvedEdits) {
        StringBuilder builder = new StringBuilder(text == null ? "" : text);
        for (ResolvedTextEdit edit : resolvedEdits) {
            int safeStart = Math.max(0, Math.min(edit.startOffset, builder.length()));
            int safeEnd = Math.max(safeStart, Math.min(edit.endOffset, builder.length()));
            builder.replace(safeStart, safeEnd, edit.newText);
        }
        return builder.toString();
    }


    List<ResolvedTextEdit> resolveTextEdits(String text, List<LspClient.TextEdit> edits) {
        List<ResolvedTextEdit> resolved = new ArrayList<>();
        if (edits == null || edits.isEmpty()) {
            return resolved;
        }
        String source = text == null ? "" : text;
        List<Integer> lineStarts = lineStartOffsets(source);
        for (int i = 0; i < edits.size(); i++) {
            LspClient.TextEdit edit = edits.get(i);
            if (edit == null) {
                continue;
            }
            int startOffset = offsetForLineCharacter(source, lineStarts, edit.getStartLine(), edit.getStartCharacter());
            int endOffset = offsetForLineCharacter(source, lineStarts, edit.getEndLine(), edit.getEndCharacter());
            if (endOffset < startOffset) {
                int swap = startOffset;
                startOffset = endOffset;
                endOffset = swap;
            }
            resolved.add(new ResolvedTextEdit(startOffset, endOffset, edit.getNewText(), i));
        }
        resolved.sort((left, right) -> {
            if (left.startOffset != right.startOffset) {
                return Integer.compare(right.startOffset, left.startOffset);
            }
            if (left.endOffset != right.endOffset) {
                return Integer.compare(right.endOffset, left.endOffset);
            }
            return Integer.compare(right.order, left.order);
        });
        return resolved;
    }


    List<Integer> lineStartOffsets(String text) {
        List<Integer> starts = new ArrayList<>();
        starts.add(0);
        for (int i = 0; i < text.length(); i++) {
            if (text.charAt(i) == '\n') {
                starts.add(i + 1);
            }
        }
        return starts;
    }


    int offsetForLineCharacter(String text, List<Integer> lineStarts, int line, int character) {
        if (lineStarts == null || lineStarts.isEmpty()) {
            return 0;
        }
        int safeLine = Math.max(0, Math.min(line, lineStarts.size() - 1));
        int lineStart = lineStarts.get(safeLine);
        int lineEnd = safeLine + 1 < lineStarts.size() ? lineStarts.get(safeLine + 1) - 1 : text.length();
        int safeCharacter = Math.max(0, character);
        return Math.max(0, Math.min(lineStart + safeCharacter, lineEnd));
    }


    String filePathFromUri(String uri) {
        if (uri == null || uri.isBlank()) {
            return null;
        }
        if (editor != null && editor.remoteWorkspaceController != null) {
            Path remotePath = editor.remoteWorkspaceController.localPathForRemoteLanguageServerUri(uri);
            if (remotePath != null) return remotePath.toFile().getAbsolutePath();
        }
        if (!uri.startsWith("file:")) {
            return null;
        }
        try {
            return Path.of(new URI(uri)).toFile().getAbsolutePath();
        } catch (IllegalArgumentException | URISyntaxException e) {
            return uri.substring("file://".length());
        }
    }


    String currentCompletionPrefix() {
        int caret = Math.min(editor.writingArea.getCaretPosition(), editor.writingArea.getDocument().getLength());
        int end = caret;
        StringBuilder prefix = new StringBuilder();
        try {
            while (end > 0) {
                int start = Math.max(0, end - 256);
                String nearby = editor.writingArea.getDocument().getText(start, end - start);
                int wordStart = nearby.length();
                while (wordStart > 0 && editor.isWordCharacter(nearby.charAt(wordStart - 1))) {
                    wordStart--;
                }
                prefix.insert(0, nearby.substring(wordStart));
                if (wordStart > 0) break;
                end = start;
            }
            return prefix.toString();
        } catch (BadLocationException ignored) {
            return "";
        }
    }


    List<String> collectBufferCompletions(String prefix) {
        List<String> matches = new ArrayList<>();
        if (prefix == null || prefix.isEmpty()) {
            return matches;
        }

        java.util.LinkedHashSet<String> unique = new java.util.LinkedHashSet<>();
        StringBuilder word = new StringBuilder();
        int caret = editor.writingArea.getCaretPosition();
        int start = Math.max(0, caret - 8192);
        int end = Math.min(editor.writingArea.getDocument().getLength(), caret + 8192);
        String text;
        try {
            text = editor.writingArea.getDocument().getText(start, end - start);
        } catch (BadLocationException ignored) {
            return matches;
        }
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (editor.isWordCharacter(c)) {
                word.append(c);
            } else if (!word.isEmpty()) {
                addCompletionCandidate(prefix, unique, word.toString());
                word.setLength(0);
            }
        }
        if (!word.isEmpty()) {
            addCompletionCandidate(prefix, unique, word.toString());
        }

        for (String candidate : unique) {
            matches.add(candidate);
            if (matches.size() >= 10) {
                break;
            }
        }
        return matches;
    }


    void addCompletionCandidate(String prefix, java.util.LinkedHashSet<String> unique, String candidate) {
        if (candidate.length() <= prefix.length()) {
            return;
        }
        if (candidate.startsWith(prefix)) {
            unique.add(candidate);
        }
    }


    void applyCompletion(String prefix, String completion) {
        int caret = editor.writingArea.getCaretPosition();
        int start = Math.max(0, caret - (prefix == null ? 0 : prefix.length()));
        editor.writingArea.replaceRange(completion, start, caret);
        editor.writingArea.setCaretPosition(start + completion.length());
        editor.markModified();
    }

    private String lspErrorFor(FileBuffer buffer) {
        if (buffer == null) {
            return null;
        }
        String extension = bufferExtension(buffer);
        try {
            return editor.lspErrors.get(new LspServerKey(extension, workspaceRootPath(buffer)));
        } catch (IOException ignored) {
            return editor.lspErrors.get(new LspServerKey(extension, null));
        }
    }

    String completionUnavailableReason(FileBuffer buffer) {
        if (buffer == null || !buffer.hasFilePath()) {
            return "buffer is not file-backed";
        }
        LspClient client = existingLspClient(buffer);
        if (client != null && client.isAlive() && client.supports(LspCapability.COMPLETION)) {
            return null;
        }
        String error = lspErrorFor(buffer);
        if (error != null && !error.isBlank()) {
            return error;
        }
        return client == null ? "language server is not configured" : client.capabilityUnavailableReason(LspCapability.COMPLETION);
    }

    private int stopServersForExtension(String extension) {
        cancelAutomaticLaunches(key -> key.extension().equalsIgnoreCase(extension));
        List<LspServerKey> keys = new ArrayList<>();
        for (LspServerKey key : editor.lspClients.keySet()) {
            if (key.extension().equalsIgnoreCase(extension)) {
                keys.add(key);
            }
        }
        for (LspServerKey key : keys) {
            LspClient client = editor.lspClients.remove(key);
            if (client != null) client.stop();
            remoteLspEndpoints.remove(key);
        }
        return keys.size();
    }

    void stopServersForWorkspace(Path workspace) {
        Path root = workspace == null ? null : workspace.toAbsolutePath().normalize();
        if (root == null) return;
        cancelDefinition();
        cancelAutomaticLaunches(key -> key.workspaceRoot() != null && key.workspaceRoot().startsWith(root));
        List<LspServerKey> keys = new ArrayList<>();
        for (LspServerKey key : editor.lspClients.keySet()) {
            Path serverRoot = key.workspaceRoot();
            if (serverRoot != null && serverRoot.startsWith(root)) keys.add(key);
        }
        for (LspServerKey key : keys) {
            LspClient client = editor.lspClients.remove(key);
            if (client != null) client.stop();
            remoteLspEndpoints.remove(key);
        }
        editor.lspErrors.entrySet().removeIf(entry -> entry.getKey().workspaceRoot() != null && entry.getKey().workspaceRoot().startsWith(root));
        for (FileBuffer buffer : editor.buffers) {
            if (buffer == null || !buffer.hasFilePath()) continue;
            Path path = new File(buffer.getFilePath()).toPath().toAbsolutePath().normalize();
            if (!path.startsWith(root)) continue;
            String uri = bufferUri(buffer);
            editor.lspDocumentVersions.remove(uri);
            documentSyncStates.remove(uri);
        }
    }

    private void removeErrorsForExtension(String extension) {
        editor.lspErrors.entrySet().removeIf(entry -> entry.getKey().extension().equalsIgnoreCase(extension));
    }

    private boolean hasExtension(String uri, String extension) {
        int dot = uri == null ? -1 : uri.lastIndexOf('.');
        return dot >= 0 && uri.substring(dot + 1).equalsIgnoreCase(extension);
    }


    LspClient resolveLspClient(FileBuffer buffer) {
        if (buffer == null || !buffer.hasFilePath()) {
            return null;
        }
        String extension = bufferExtension(buffer);
        if (extension.isEmpty()) {
            editor.lspErrors.put(new LspServerKey("", null), "file has no recognized extension");
            return null;
        }

        Path workspaceRoot;
        try {
            workspaceRoot = workspaceRootPath(buffer);
        } catch (IOException e) {
            editor.lspErrors.put(new LspServerKey(extension, null), e.getMessage());
            return null;
        }
        LspServerKey key = new LspServerKey(extension, workspaceRoot);

        LspClient existing = editor.lspClients.get(key);
        if (existing != null && existing.isAlive()) {
            editor.lspErrors.remove(key);
            return existing;
        }
        if (automaticLaunchJobs.containsKey(key)) return null;
        if (existing != null) {
            existing.stop();
            editor.lspClients.remove(key);
            remoteLspEndpoints.remove(key);
        }

        String command = editor.configManager.getLspCommand(extension);
        boolean userConfigured = command != null && !command.isBlank();
        try {
            String[] args = editor.configManager.getLspArgs(extension);
            if (command == null || command.isBlank()) {
                String[] builtin = builtinLspCommand(extension);
                if (builtin == null || builtin.length == 0) {
                    editor.lspErrors.put(key, "no server configured for ." + extension);
                    return null;
                }
                command = builtin[0];
                args = java.util.Arrays.copyOfRange(builtin, 1, builtin.length);
            }
            List<String> invocation = new ArrayList<>();
            invocation.add(command);
            if (args != null) java.util.Collections.addAll(invocation, args);
            RemoteLspEndpoint remote = null;
            boolean remoteWorkspace = editor.remoteWorkspaceController != null
                && editor.remoteWorkspaceController.remoteLanguageServerUri(workspaceRoot) != null;
            boolean devContainer = !remoteWorkspace && editor.devContainerController != null && editor.devContainerController.hasConfiguration(workspaceRoot);
            if (editor.configManager.getRemoteLspEnabled() && (remoteWorkspace || devContainer)) {
                if (!userConfigured) {
                    editor.lspErrors.put(key, "remote LSP requires an explicit global lsp." + extension + ".command configured for the remote environment");
                    return null;
                }
                remote = remoteWorkspace ? editor.remoteWorkspaceController.languageServerEndpoint(workspaceRoot, invocation)
                    : editor.devContainerController.languageServerEndpoint(workspaceRoot, invocation);
                if (remote == null) {
                    editor.lspErrors.put(key, "the selected remote workspace does not support remote language servers");
                    return null;
                }
            }
            LspClient client = remote == null
                ? new LspClient(command, args, workspaceRoot, editor.configManager.getLspFeatureSettings(),
                    editor.toolchainService.environment(workspaceRoot))
                : new LspClient(remote.command(), workspaceRoot, remote.rootUri(), editor.configManager.getLspFeatureSettings());
            client.setWorkspaceEditHandler(this::applyWorkspaceEditFromServer);
            client.setDiagnosticsChangedHandler(() -> SwingUtilities.invokeLater(() -> {
                scheduleDiagnosticRefresh();
                editor.problemsController.diagnosticsChanged();
            }));
            editor.lspClients.put(key, client);
            if (remote == null) remoteLspEndpoints.remove(key);
            else remoteLspEndpoints.put(key, remote);
            editor.lspErrors.remove(key);
            return client;
        } catch (IOException | IllegalArgumentException e) {
            remoteLspEndpoints.remove(key);
            editor.lspErrors.put(key, e.getMessage());
            return null;
        }
    }


    private void startLspAutomatically(FileBuffer buffer) {
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile() || editor.closingDown) return;
        String extension = bufferExtension(buffer);
        if (extension.isEmpty()) return;
        Path root;
        try {
            root = workspaceRootPath(buffer);
        } catch (IOException error) {
            editor.lspErrors.put(new LspServerKey(extension, null), error.getMessage());
            return;
        }
        LspServerKey key = new LspServerKey(extension, root);
        LspClient stale = editor.lspClients.get(key);
        if (stale != null && !stale.isAlive()) {
            for (FileBuffer open : editor.buffers) {
                if (open == null || !open.hasFilePath() || !extension.equals(bufferExtension(open))) continue;
                try {
                    if (!root.equals(workspaceRootPath(open))) continue;
                    String uri = bufferUri(open);
                    editor.lspDocumentVersions.remove(uri);
                    documentSyncStates.remove(uri);
                } catch (IOException ignored) { }
            }
            editor.lspClients.remove(key);
            remoteLspEndpoints.remove(key);
            stopLspLater(stale);
        }
        if (automaticLaunchJobs.containsKey(key) || failedAutomaticLaunches.contains(key)) return;

        String command = editor.configManager.getLspCommand(extension);
        boolean userConfigured = command != null && !command.isBlank();
        String[] args;
        try {
            args = editor.configManager.getLspArgs(extension);
        } catch (IllegalArgumentException error) {
            editor.lspErrors.put(key, error.getMessage());
            failedAutomaticLaunches.add(key);
            return;
        }
        if (!userConfigured) {
            String[] builtin = builtinLspCommand(extension);
            if (builtin == null || builtin.length == 0) {
                editor.lspErrors.put(key, "no server configured for ." + extension);
                failedAutomaticLaunches.add(key);
                return;
            }
            command = builtin[0];
            args = Arrays.copyOfRange(builtin, 1, builtin.length);
        }
        String resolvedCommand = command;
        String[] resolvedArgs = args == null ? new String[0] : args.clone();
        List<String> invocation = new ArrayList<>();
        invocation.add(resolvedCommand);
        Collections.addAll(invocation, resolvedArgs);
        List<String> commandLine = List.copyOf(invocation);
        LspFeatureSettings features = editor.configManager.getLspFeatureSettings();
        boolean remoteWorkspace = editor.remoteWorkspaceController != null
            && editor.remoteWorkspaceController.remoteLanguageServerUri(root) != null;
        boolean devContainer = !remoteWorkspace && editor.devContainerController != null
            && editor.devContainerController.hasConfiguration(root);
        boolean remoteEnabled = editor.configManager.getRemoteLspEnabled() && (remoteWorkspace || devContainer);
        if (remoteEnabled && !userConfigured) {
            editor.lspErrors.put(key, "remote LSP requires an explicit global lsp." + extension + ".command configured for the remote environment");
            failedAutomaticLaunches.add(key);
            return;
        }

        editor.lspErrors.put(key, "language server is starting");
        long launchStartedAt = System.nanoTime();
        int jobId = editor.asyncJobService.submit("Start language server ." + extension, token -> {
            RemoteLspEndpoint endpoint = null;
            if (remoteEnabled) {
                endpoint = remoteWorkspace
                    ? editor.remoteWorkspaceController.languageServerEndpoint(root, commandLine)
                    : editor.devContainerController.languageServerEndpoint(root, commandLine);
                if (endpoint == null) throw new IOException("the selected remote workspace does not support remote language servers");
            }
            LspClient client = endpoint == null
                ? new LspClient(resolvedCommand, resolvedArgs, root, features, editor.toolchainService.environment(root))
                : new LspClient(endpoint.command(), root, endpoint.rootUri(), features);
            if (token.isCancelled()) {
                client.stop();
                return null;
            }
            return new AutomaticLspStart(client, endpoint);
        }, (job, started, error) -> {
            Integer activeJob = automaticLaunchJobs.get(key);
            if (activeJob == null || activeJob != job.getId() || editor.closingDown) {
                if (started != null) stopLspLater(started.client());
                return;
            }
            automaticLaunchJobs.remove(key);
            if (error != null || started == null || job.getStatus() != AsyncJobService.Status.SUCCEEDED) {
                if (editor.perfService != null && job.getStatus() == AsyncJobService.Status.FAILED) {
                    editor.perfService.recordDuration("lsp.startup.failed", launchStartedAt, "." + extension);
                }
                failedAutomaticLaunches.add(key);
                String reason = error == null ? null : error.getMessage();
                editor.lspErrors.put(key, reason == null || reason.isBlank() ? "language server failed to start" : reason);
                return;
            }
            if (editor.lspClients.containsKey(key)) {
                stopLspLater(started.client());
                editor.lspErrors.remove(key);
                return;
            }
            List<FileBuffer> matchingBuffers = new ArrayList<>();
            for (FileBuffer open : editor.buffers) {
                if (open == null || !open.hasFilePath() || open.isLargeFile()
                    || !extension.equals(bufferExtension(open))) continue;
                try {
                    if (root.equals(workspaceRootPath(open))) matchingBuffers.add(open);
                } catch (IOException ignored) { }
            }
            if (matchingBuffers.isEmpty()) {
                stopLspLater(started.client());
                editor.lspErrors.remove(key);
                return;
            }
            LspClient client = started.client();
            client.setWorkspaceEditHandler(this::applyWorkspaceEditFromServer);
            client.setDiagnosticsChangedHandler(() -> SwingUtilities.invokeLater(() -> {
                scheduleDiagnosticRefresh();
                editor.problemsController.diagnosticsChanged();
            }));
            editor.lspClients.put(key, client);
            if (editor.perfService != null) {
                editor.perfService.recordDuration("lsp.startup", launchStartedAt, "." + extension);
            }
            if (started.endpoint() == null) remoteLspEndpoints.remove(key);
            else remoteLspEndpoints.put(key, started.endpoint());
            editor.lspErrors.remove(key);
            for (FileBuffer open : matchingBuffers) syncLspOpen(open);
            editor.requestStatusBarRefresh();
        });
        automaticLaunchJobs.put(key, jobId);
    }

    private void cancelAutomaticLaunches(java.util.function.Predicate<LspServerKey> matches) {
        failedAutomaticLaunches.removeIf(matches);
        for (LspServerKey key : new ArrayList<>(automaticLaunchJobs.keySet())) {
            if (!matches.test(key)) continue;
            Integer jobId = automaticLaunchJobs.remove(key);
            if (jobId != null) editor.asyncJobService.cancel(jobId);
        }
    }

    private static void stopLspLater(LspClient client) {
        Thread.ofVirtual().name("shed-stale-lsp").start(client::stop);
    }


    record DocumentBinding(File file, String uri, LspClient client) { }

    DocumentBinding captureDocumentBinding(FileBuffer buffer) {
        return buffer.hasFilePath() ? new DocumentBinding(buffer.getFile(), bufferUri(buffer), existingLspClient(buffer))
            : new DocumentBinding(null, null, null);
    }

    boolean syncDocumentBinding(FileBuffer buffer, DocumentBinding previous) {
        File current = buffer.hasFilePath() ? buffer.getFile() : null;
        if (Objects.equals(previous.file(), current)) return false;
        if (previous.uri() != null) {
            boolean wasOpen = editor.lspDocumentVersions.remove(previous.uri()) != null;
            documentSyncStates.remove(previous.uri());
            if (wasOpen && previous.client() != null && previous.client().isAlive()) previous.client().didClose(previous.uri());
        }
        if (pendingLspChange == buffer) pendingLspChange = null;
        if (pendingLspDecoration == buffer) pendingLspDecoration = null;
        if (buffer == editor.getCurrentBuffer()) clearLspDecorations();
        // Resource acceptance may notify an existing server, but does not start a project process.
        LspClient next = existingLspClient(buffer);
        if (next != null && next.isAlive()) syncLspOpen(buffer);
        return true;
    }

    void syncLspOpen(FileBuffer buffer) {
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) {
            return;
        }
        LspClient client = existingLspClient(buffer);
        if (client == null || !client.isAlive()) {
            startLspAutomatically(buffer);
            return;
        }
        String uri = bufferUri(buffer);
        if (editor.lspDocumentVersions.containsKey(uri)) {
            return;
        }
        VersionedTextSnapshot content = buffer.textSnapshot();
        client.didOpen(uri, languageId(buffer), content.text());
        editor.lspDocumentVersions.put(uri, 1);
        documentSyncStates.put(uri, new LspDocumentSyncState(content));
        scheduleLspDecorations(buffer);
    }


    void syncLspChange(FileBuffer buffer) {
        syncLspChange(buffer, (FileBuffer.DocumentTextChange) null);
    }

    void syncLspChange(FileBuffer buffer, int offset, int removedLength, String insertedText) {
        syncLspChange(buffer, new FileBuffer.DocumentTextChange(buffer == null ? null : buffer.textSnapshot(),
            buffer == null ? null : buffer.textSnapshot(), offset, removedLength, insertedText == null ? "" : insertedText, false));
    }

    void syncLspChange(FileBuffer buffer, FileBuffer.DocumentTextChange textChange) {
        if (definitionRequests != null) definitionRequests.sourceChanged(buffer);
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) {
            return;
        }
        String uri = bufferUri(buffer);
        boolean wasOpen = editor.lspDocumentVersions.containsKey(uri);
        syncLspOpen(buffer);
        if (!wasOpen) {
            return;
        }
        LspDocumentSyncState syncState = documentSyncStates.computeIfAbsent(uri, ignored -> new LspDocumentSyncState(buffer.textSnapshot()));
        if (textChange != null) {
            syncState.apply(textChange);
        } else {
            syncState.reconcile(buffer.textSnapshot());
        }
        clearLspDecorations();
        pendingLspChange = buffer;
        if (lspChangeTimer == null) {
            lspChangeTimer = new Timer(CHANGE_DEBOUNCE_MS, event -> flushPendingLspChange(pendingLspChange));
            lspChangeTimer.setRepeats(false);
        }
        lspChangeTimer.restart();
    }

    void flushPendingLspChange(FileBuffer buffer) {
        if (buffer == null || pendingLspChange != buffer) {
            return;
        }
        if (lspChangeTimer != null) {
            lspChangeTimer.stop();
        }
        pendingLspChange = null;
        sendLspChange(buffer);
    }

    void shutdown() {
        if (definitionRequests != null) definitionRequests.close();
        cancelAutomaticLaunches(key -> true);
        workspaceSymbolCoordinator.close();
        if (lspChangeTimer != null) {
            lspChangeTimer.stop();
        }
        if (lspDecorationTimer != null) {
            lspDecorationTimer.stop();
        }
        if (lspDecorationJobId >= 0) {
            editor.asyncJobService.cancel(lspDecorationJobId);
            lspDecorationJobId = -1;
        }
        clearDocumentHighlights();
        pendingLspChange = null;
        pendingLspDecoration = null;
    }

    private void sendLspChange(FileBuffer buffer) {
        long started = System.nanoTime();
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) {
            return;
        }
        LspClient client = existingLspClient(buffer);
        if (client == null || !client.isAlive()) {
            startLspAutomatically(buffer);
            return;
        }
        syncLspOpen(buffer);
        String uri = bufferUri(buffer);
        LspDocumentSyncState syncState = documentSyncStates.computeIfAbsent(uri, ignored -> new LspDocumentSyncState(buffer.textSnapshot()));
        if (!syncState.hasPendingChanges()) {
            scheduleLspDecorations(buffer);
            return;
        }
        int version = editor.lspDocumentVersions.getOrDefault(uri, 1) + 1;
        editor.lspDocumentVersions.put(uri, version);
        List<LspDocumentChange> changes = syncState.drainChanges();
        String content = client.documentSyncKind() == LspClient.DocumentSyncKind.INCREMENTAL && !changes.isEmpty()
            ? null : syncState.text();
        client.didChange(uri, version, changes, content);
        scheduleDiagnosticRefresh();
        scheduleLspDecorations(buffer);
        if (editor.perfService != null) {
            editor.perfService.recordDuration("lsp.change", started, "chars=" + syncState.length());
        }
    }


    void scheduleDiagnosticRefresh() {
        if (editor.diagnosticRefreshTimer == null) {
            editor.diagnosticRefreshTimer = new javax.swing.Timer(500, ev -> editor.refreshDiagnosticRanges());
            editor.diagnosticRefreshTimer.setRepeats(false);
        }
        editor.diagnosticRefreshTimer.restart();
    }

    void refreshLspDecorations() {
        FileBuffer buffer = editor.getCurrentBuffer();
        if (buffer == null || !buffer.hasFilePath()) {
            clearLspDecorations();
            return;
        }
        if (!editor.configManager.getLspSemanticTokensInline() && !editor.configManager.getLspInlayHintsInline()) {
            clearLspDecorations();
            return;
        }
        scheduleLspDecorations(buffer);
    }

    private void scheduleLspDecorations(FileBuffer buffer) {
        if (buffer == null || !buffer.hasFilePath() || buffer.isLargeFile()) {
            return;
        }
        if (!editor.configManager.getLspSemanticTokensInline() && !editor.configManager.getLspInlayHintsInline()) {
            if (buffer == editor.getCurrentBuffer()) clearLspDecorations();
            return;
        }
        pendingLspDecoration = buffer;
        if (lspDecorationTimer == null) {
            lspDecorationTimer = new Timer(DECORATION_DEBOUNCE_MS, event -> requestLspDecorations(pendingLspDecoration));
            lspDecorationTimer.setRepeats(false);
        }
        lspDecorationTimer.restart();
    }

    private void requestLspDecorations(FileBuffer buffer) {
        pendingLspDecoration = null;
        if (buffer == null || buffer != editor.getCurrentBuffer() || !buffer.hasFilePath() || buffer.isLargeFile()) {
            return;
        }
        LspClient client = existingLspClient(buffer);
        String uri = bufferUri(buffer);
        Integer version = editor.lspDocumentVersions.get(uri);
        if (client == null || version == null || !client.isAlive()) {
            clearLspDecorations();
            return;
        }
        boolean semanticEnabled = editor.configManager.getLspSemanticTokensInline() && client.supports(LspCapability.SEMANTIC_TOKENS);
        boolean inlayEnabled = editor.configManager.getLspInlayHintsInline() && client.supports(LspCapability.INLAY_HINTS);
        if (!semanticEnabled && !inlayEnabled) {
            clearLspDecorations();
            return;
        }
        VersionedTextSnapshot text = buffer.textSnapshot();
        VersionedTextSnapshot.Position textEnd = text.positionAt(text.length());
        LspPosition end = new LspPosition(textEnd.line(), textEnd.character());
        if (lspDecorationJobId >= 0) editor.asyncJobService.cancel(lspDecorationJobId);
        LspDecorationRequest request = new LspDecorationRequest(buffer, client, uri, version, text, semanticEnabled, inlayEnabled, end);
        lspDecorationJobId = editor.asyncJobService.submit("LSP decorations", token -> {
            List<LspClient.SemanticToken> semanticTokens = request.semanticEnabled()
                ? request.client().semanticTokens(request.uri()) : List.of();
            if (token.isCancelled()) return null;
            List<LspClient.InlayHint> inlayHints = request.inlayEnabled()
                ? request.client().inlayHints(request.uri(), request.end().line(), request.end().character()) : List.of();
            return new LspDecorationResult(request, semanticTokens, inlayHints);
        }, (snapshot, result, error) -> applyLspDecorations(snapshot, result, error));
    }

    private void applyLspDecorations(AsyncJobService.JobSnapshot snapshot, LspDecorationResult result, Exception error) {
        if (snapshot == null || snapshot.getStatus() != AsyncJobService.Status.SUCCEEDED || result == null || error != null) {
            return;
        }
        lspDecorationJobId = -1;
        LspDecorationRequest request = result.request();
        if (request.buffer() != editor.getCurrentBuffer() || request.text() != request.buffer().textSnapshot()
            || !Objects.equals(request.version(), editor.lspDocumentVersions.get(request.uri())) || existingLspClient(request.buffer()) != request.client()) {
            return;
        }
        editor.lspSemanticSpans.clear();
        if (request.semanticEnabled()) {
            for (LspClient.SemanticToken token : result.semanticTokens()) {
                Color color = semanticTokenColor(request.client().semanticTokenTypeName(token.type()));
                int start = offsetForPosition(request.text(), token.line(), token.character());
                int end = Math.min(request.text().length(), start + Math.max(0, token.length()));
                if (color != null && end > start) editor.lspSemanticSpans.add(new SyntaxSpan(start, end, color));
            }
            editor.lspSemanticSpans.sort(Comparator.comparingInt(span -> span.start));
        }
        editor.lspInlayHintOverlays.clear();
        if (request.inlayEnabled()) {
            Map<Integer, StringBuilder> labelsByOffset = new TreeMap<>();
            for (LspClient.InlayHint hint : result.inlayHints()) {
                int offset = offsetForPosition(request.text(), hint.line(), hint.character());
                if (offset > request.text().length()) continue;
                String label = hint.label().replace('\n', ' ').replace('\r', ' ').strip();
                if (label.isEmpty()) continue;
                StringBuilder labels = labelsByOffset.computeIfAbsent(offset, ignored -> new StringBuilder());
                if (!labels.isEmpty()) labels.append(' ');
                labels.append(label);
                if (labelsByOffset.size() >= MAX_INLINE_INLAY_HINTS) break;
            }
            for (Map.Entry<Integer, StringBuilder> entry : labelsByOffset.entrySet()) {
                editor.lspInlayHintOverlays.add(new LspInlayHintOverlay(entry.getKey(), entry.getValue().toString()));
            }
        }
        editor.writingArea.repaint();
    }

    void clearLspDecorations() {
        if (editor.lspSemanticSpans.isEmpty() && editor.lspInlayHintOverlays.isEmpty() && editor.lspDocumentHighlightTags.isEmpty()
            && documentHighlightJobId < 0) return;
        editor.lspSemanticSpans.clear();
        editor.lspInlayHintOverlays.clear();
        clearDocumentHighlights();
        if (editor.writingArea != null) editor.writingArea.repaint();
    }

    private void applyDocumentHighlights(AsyncJobService.JobSnapshot snapshot, DocumentHighlightResult result, Exception error) {
        if (snapshot == null || snapshot.getStatus() != AsyncJobService.Status.SUCCEEDED || result == null || error != null) return;
        documentHighlightJobId = -1;
        DocumentHighlightRequest request = result.request();
        if (request.generation() != documentHighlightGeneration || request.buffer() != editor.getCurrentBuffer()
            || request.text() != request.buffer().textSnapshot() || !Objects.equals(request.version(), editor.lspDocumentVersions.get(request.uri()))
            || existingLspClient(request.buffer()) != request.client()) return;
        removeDocumentHighlightTags();
        Highlighter highlighter = editor.writingArea.getHighlighter();
        Color selection = editor.configManager.getSelectionColor();
        int rendered = 0;
        for (LspClient.DocumentHighlight highlight : result.highlights()) {
            int start = offsetForPosition(request.text(), highlight.startLine(), highlight.startCharacter());
            int end = offsetForPosition(request.text(), highlight.endLine(), highlight.endCharacter());
            if (end <= start || start < 0 || end > request.text().length()) continue;
            int alpha = highlight.kind() == 3 ? 112 : highlight.kind() == 2 ? 88 : 96;
            try {
                Object tag = highlighter.addHighlight(start, end, new DefaultHighlighter.DefaultHighlightPainter(
                    new Color(selection.getRed(), selection.getGreen(), selection.getBlue(), alpha)));
                editor.lspDocumentHighlightTags.add(new LspDocumentHighlightTag(highlighter, tag));
                rendered++;
            } catch (BadLocationException ignored) {
            }
        }
        editor.writingArea.repaint();
        editor.showMessage(rendered == 0 ? "No document highlights" : "Highlighted " + rendered + " occurrence" + (rendered == 1 ? "" : "s"));
    }

    private void clearDocumentHighlights() {
        if (documentHighlightJobId >= 0) {
            editor.asyncJobService.cancel(documentHighlightJobId);
            documentHighlightJobId = -1;
        }
        documentHighlightGeneration++;
        removeDocumentHighlightTags();
    }

    private void removeDocumentHighlightTags() {
        for (LspDocumentHighlightTag entry : editor.lspDocumentHighlightTags) {
            if (entry.highlighter() != null && entry.tag() != null) entry.highlighter().removeHighlight(entry.tag());
        }
        editor.lspDocumentHighlightTags.clear();
    }

    private Color semanticTokenColor(String type) {
        return switch (type == null ? "" : type.toLowerCase(Locale.ROOT)) {
            case "namespace", "type", "class", "enum", "interface", "struct", "typeparameter" -> editor.configManager.getSyntaxTypeColor();
            case "function", "method" -> editor.configManager.getSyntaxFunctionColor();
            case "macro", "keyword", "modifier" -> editor.configManager.getSyntaxKeywordColor();
            case "comment" -> editor.configManager.getSyntaxCommentColor();
            case "string", "regexp" -> editor.configManager.getSyntaxStringColor();
            case "number" -> editor.configManager.getSyntaxNumberColor();
            default -> null;
        };
    }

    private static int offsetForPosition(VersionedTextSnapshot text, int line, int character) {
        if (text == null || line < 0 || character < 0) return 0;
        return text.offsetAt(line, character);
    }

    private record LspPosition(int line, int character) { }

    private record LspDecorationRequest(FileBuffer buffer, LspClient client, String uri, Integer version, VersionedTextSnapshot text,
                                        boolean semanticEnabled, boolean inlayEnabled, LspPosition end) { }

    private record LspDecorationResult(LspDecorationRequest request, List<LspClient.SemanticToken> semanticTokens,
                                       List<LspClient.InlayHint> inlayHints) { }

    private record DocumentHighlightRequest(FileBuffer buffer, LspClient client, String uri, Integer version, VersionedTextSnapshot text,
                                            long generation, int line, int column) { }
    private record DocumentHighlightResult(DocumentHighlightRequest request, List<LspClient.DocumentHighlight> highlights) { }


    public void notifyCurrentBufferSaved() {
        notifyBufferSaved(editor.getCurrentBuffer());
    }

    public void notifyBufferSaved(FileBuffer buffer) {
        if (buffer == null || !buffer.hasFilePath()) {
            return;
        }
        editor.invalidateGitBlame(buffer);
        flushPendingLspChange(buffer);
        syncLspOpen(buffer);
        LspClient client = resolveLspClient(buffer);
        if (client != null) {
            client.didSave(bufferUri(buffer));
        }
        editor.refreshGitGutter();
    }


    void pollLspNotifications(FileBuffer buffer) {
        LspClient client = existingLspClient(buffer);
        if (client != null) {
            client.drainNotifications();
        }
    }


    LspClient existingLspClient(FileBuffer buffer) {
        if (buffer == null || !buffer.hasFilePath()) {
            return null;
        }
        try {
            return editor.lspClients.get(new LspServerKey(bufferExtension(buffer), workspaceRootPath(buffer)));
        } catch (IOException ignored) {
            return null;
        }
    }


    String bufferUri(FileBuffer buffer) {
        Path path = new File(buffer.getFilePath()).toPath().toAbsolutePath().normalize();
        RemoteLspEndpoint endpoint = remoteLspEndpointFor(buffer);
        if (endpoint != null) {
            String remoteUri = endpoint.uriFor(path);
            if (remoteUri != null) return remoteUri;
        }
        return path.toUri().toString();
    }

    private RemoteLspEndpoint remoteLspEndpointFor(FileBuffer buffer) {
        if (buffer == null || !buffer.hasFilePath()) return null;
        try {
            return remoteLspEndpoints.get(new LspServerKey(bufferExtension(buffer), workspaceRootPath(buffer)));
        } catch (IOException ignored) {
            return null;
        }
    }


    String languageId(FileBuffer buffer) {
        return editor.lspService.languageId(bufferExtension(buffer), buffer.getFileType());
    }


    String bufferExtension(FileBuffer buffer) {
        String path = buffer.getFilePath();
        if (path == null) {
            return "";
        }
        String name = Path.of(path).getFileName().toString().toLowerCase(Locale.ROOT);
        if (name.equals("cmakelists.txt") || name.endsWith(".cmake.in")) return "cmake";
        int dot = path.lastIndexOf('.');
        if (dot < 0 || dot >= path.length() - 1) {
            return canonicalExtension(buffer.getFileType());
        }
        return path.substring(dot + 1).toLowerCase();
    }

    private static String canonicalExtension(FileType fileType) {
        if (fileType == null) return "";
        return switch (fileType) {
            case KOTLIN -> "kt";
            case CSHARP -> "cs";
            case PHP -> "php";
            case RUBY -> "rb";
            case SWIFT -> "swift";
            case CMAKE -> "cmake";
            default -> "";
        };
    }


    String[] builtinLspCommand(String extension) {
        return editor.lspService.builtinCommand(extension);
    }

    static final class WorkspaceEditPlan {
        final Map<String, String> stagedTextByPath = new LinkedHashMap<>();
        final Map<String, TextFileCodec.Image> diskImages = new LinkedHashMap<>();
        final Map<Path, String> diskVersions = new LinkedHashMap<>();
        final List<ResourceAction> resourceActions = new ArrayList<>();
        final Set<String> touchedPaths = new LinkedHashSet<>();
        int appliedEditCount;
    }


    static final class StagedTextWrite {
        final Path path;
        final String text;
        final Path tempPath;

        StagedTextWrite(Path path, String text, Path tempPath) {
            this.path = path;
            this.text = text;
            this.tempPath = tempPath;
        }
    }


    static final class ResourceAction {
        enum Kind {
            CREATE,
            RENAME,
            DELETE
        }

        final Kind kind;
        final Path path;
        final Path targetPath;
        final boolean overwrite;
        final boolean recursive;

        private ResourceAction(Kind kind, Path path, Path targetPath, boolean overwrite, boolean recursive) {
            this.kind = kind;
            this.path = path;
            this.targetPath = targetPath;
            this.overwrite = overwrite;
            this.recursive = recursive;
        }

        static ResourceAction create(Path path, boolean overwrite) {
            return new ResourceAction(Kind.CREATE, path, null, overwrite, false);
        }

        static ResourceAction rename(Path oldPath, Path newPath, boolean overwrite) {
            return new ResourceAction(Kind.RENAME, oldPath, newPath, overwrite, false);
        }

        static ResourceAction delete(Path path, boolean recursive) {
            return new ResourceAction(Kind.DELETE, path, null, false, recursive);
        }
    }

}
